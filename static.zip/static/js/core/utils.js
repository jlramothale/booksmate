
var development = true;
var root_url = development ? "http://127.0.0.1:8000" : "https://www.booksmate.com";
var utils = {
    gotoPage: function (page) {
        window.location.href = root_url + page;
    },
    refresh: function () {
        window.location.reload();
    },
    goBack: function() {
        window.history.back();
    },
    closeModal: function(modal){
        $(modal).modal("hide");
    },
    displaySuccessAlert: function (message) {
        Swal.fire({
            title: 'Success',
            type: 'success',
            html: message,
            focusConfirm: false,
            confirmButtonText:'Ok',
        }).then((result) => {
            utils.refresh();
        });
    },
    displayErrorAlert: function (message) {
        Swal.fire({
            title: 'Attention',
            type: 'warning',
            html: message,
            focusConfirm: false,
            confirmButtonText:'Ok',
        }).then((result) => {
            utils.refresh();
        });
    },
    active: function (elementId, subMenu) {
        $(elementId).addClass("active");
        $(elementId).siblings("li").removeClass("active");
        var tmp = $(elementId).attr("class").split(" ");
        if(tmp[1] == "has-tree"){
            $(elementId).children("div .tree").addClass("show")
            $(subMenu).addClass("active");
            $(subMenu).siblings("li").removeClass("active");
        }
    },
    clearForm: function (form) {
        var f = $(form).find('.form-group');
        f.children('input').each(function () {
            $(this).val(null);
        });
        f.children('textarea').each(function () {
            $(this).val(null);
        });
    },
    getElById: function(id){
        return document.getElementById(id);
    },
    showElement: function (element) {
        $(element).show("blind");
    },
    hideElement: function (element) {
        $(element).hide();
    },
    hideShowElement: function (ele_show, ele_hide) {
        $(ele_show).show();
        $(ele_hide).hide();
    },
    handleDefaultRequest: function(url, data){
        $.post(url, data, function (resp) {
            utils.handleDefaultResponse(resp);
        });
    },
    handleDefaultResponse: function(resp){
        $('.loader').hide();
        if (resp.status === 'ok') {
            utils.displaySuccessAlert(resp.message);
        } else if (resp.status === 'error') {
            utils.displayErrorAlert(resp.message);
        }
    }
};

