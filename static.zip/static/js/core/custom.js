
$("#frmRegister").submit(function(){
    if (formValidator.validate($(this), ".input-group")) {
        if (formValidator.isEqualPasswords($("#password1"), $("#password2"))) {
            $('.loader').show();
            $.post($(this).attr("action"), $(this).serialize(), function (resp) {
                $('.loader').hide();
                if (resp.status === 'ok') {
                    utils.gotoPage(resp.message);
                } else if (resp.status === 'error') {
                    utils.displayErrorAlert(resp.message);
                }
            });
        }
    }
    return false;
});

$("#frmCompleteRegistration").submit(function(){
    if (formValidator.validate($(this), ".form-group")) {
        $('.loader').show();
        $.post($(this).attr("action"), $(this).serialize(), function (resp) {
            $('.loader').hide();
            if (resp.status === 'ok') {
                utils.gotoPage(resp.message);
            } else if (resp.status === 'error') {
                utils.displayErrorAlert(resp.message);
            }
        });
    }
    return false;
});

$("#frmLogin").submit(function(){
    if (formValidator.validate($(this), ".input-group")) {
        $('.loader').show();
        $.post($(this).attr("action"), $(this).serialize(), function (resp) {
            $('.loader').hide();
            if (resp.status === 'ok') {
                utils.gotoPage(resp.message);
            } else if (resp.status === 'error') {
                utils.displayErrorAlert(resp.message);
            }
        });
    }
    return false;
});

// alert(use_token);
// (function (window) {
//     //Open FastLink
//     var fastlinkBtn = document.getElementById('btn-fastlink');
//     fastlinkBtn.addEventListener('click', function () {
//         window.fastlink.open({
//             fastLinkURL: 'https://node.sandbox.yodlee.com/authenticate/restserver',
//             jwtToken: 'Bearer ' + use_token,
//             // params: { keyword : 'citi',
//             //     userExperienceFlow: {
//             //         'Aggregation': {}
//             //     },  
//             //     dataset: [{
//             //         name: 'BASIC_AGG_DATA', 
//             //         attribute: [{
//             //             name: 'BASIC_ACCOUNT_INFO', 
//             //             container: ['bank']
//             //         }]
//             //     }]
//             // },
//             onSuccess: function (data) {
//                 console.log(data);
//                 // alert(data)
//             },
//             onError: function (data) {
//                 console.log(data);
//                 // alert(data)
//             },
//             onExit: function (data) {
//                 console.log(data);
//                 // alert(data)
//             },
//             onEvent: function (data) {
//                 console.log(data);
//                 // alert(data)
//             }
//         }, 'container-fastlink');
//     }, false);
// }(window));



