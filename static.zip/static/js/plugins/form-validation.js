

var formValidator = {

    isEqualPasswords: function (pass1, pass2) {
        if ($(pass1).val() !== $(pass2).val()) {
            $(pass1).addClass("form-error").next('.validation').html("Passwords do not match").show();
            $(pass2).addClass("form-error").next('.validation').html("Passwords do not match").show();
            return false;
        }
        return true;
    },
    isValidUrl: function (value) {
        var urlExp = /^(http[s]?:\/\/){0,1}(www\.){0,1}[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,5}[\.]{0,1}/;
        if (value !== '') {
            if (urlExp.test(value)) {
                return true
            }
        }
        return false;
    },
    validate: function (form, items) {
        var f = $(form).find(items),
                ferror = false,
                cellExp = /^\d{10}$/,
                idNumberExp = /^\d{13}$/,
                emailExp = /^[^\s()<>@,;:\/]+@\w[\w\.-]+\.[a-z]{2,}$/i,
                passExp = /^(?=.*\d)(?=.*[@#$%*()])(?=.*[a-z])(?=.*[A-Z])[0-9A-Za-z@#$%*()]{6,100}$/,
                urlExp = /^(http[s]?:\/\/){0,1}(www\.){0,1}[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,5}[\.]{0,1}/;
        f.children('input').each(function () {
            var i = $(this); // current input
            var rule = i.attr('data-rule');
            if (rule !== undefined) {
                var ierror = false;
                var pos = rule.indexOf(':', 0);
                if (pos >= 0) {
                    var exp = rule.substr(pos + 1, rule.length);
                    rule = rule.substr(0, pos);
                } else {
                    rule = rule.substr(pos + 1, rule.length);
                }
                switch (rule) {
                    case 'password':
                        if (!passExp.test(i.val())) {
                            ferror = ierror = true;
                        }
                        break;
                    case 'email':
                        if (!emailExp.test(i.val())) {
                            ferror = ierror = true;
                        }
                        break;
                    case 'cell':
                        if (!cellExp.test(i.val())) {
                            ferror = ierror = true;
                        }
                        break;
                    case 'idnumber':
                        if (!idNumberExp.test(i.val())) {
                            ferror = ierror = true;
                        }
                        break;
                    case 'number':
                        if (i.val() === '' || isNaN(i.val())) {
                            ferror = ierror = true;
                        }
                        break;
                    case 'url':
                        if (!urlExp.test(i.val())) {
                            ferror = ierror = true;
                        }
                        break;
                    case 'maxlen':
                        if (i.val().length < parseInt(exp)) {
                            ferror = ierror = true;
                        }
                        break;
                    case 'minlen':
                        if (i.val().length > parseInt(exp)) {
                            ferror = ierror = true;
                        }
                        break;
                    case 'regexp':
                        exp = new RegExp(exp);
                        if (!exp.test(i.val())) {
                            ferror = ierror = true;
                        }
                        break;
                    case 'required':
                        if (i.val() === '') {
                            ferror = ierror = true;
                        }
                        break;
                    case 'checked':
                        if (!i.is(":checked")) {
                            ferror = ierror = true;
                        }
                        break;
                }
                if (ierror) {
                    i.addClass("form-error").next(".validation").html("This field is required").show();
                } else {
                    i.addClass("form-success");
                    i.removeClass("form-error").next(".validation").hide();
                }
            }
        });
        f.children('textarea').each(function () {
            var i = $(this);
            var rule = i.attr('data-rule');
            if (rule !== undefined) {
                var ierror = false;
                var pos = rule.indexOf(':', 0);
                if (pos >= 0) {
                    var exp = rule.substr(pos + 1, rule.length);
                    rule = rule.substr(0, pos);
                } else {
                    rule = rule.substr(pos + 1, rule.length);
                }
                switch (rule) {
                    case 'required':
                        if (i.val() === '') {
                            ferror = ierror = true;
                        }
                        break;
                    case 'maxlen':
                        if (i.val().length < parseInt(exp)) {
                            ferror = ierror = true;
                        }
                        break;
                }
                if (ierror) {
                    i.addClass("form-error").next(".validation").html("This field is required").show();
                } else {
                    i.addClass("form-success");
                    i.removeClass("form-error").next(".validation").hide();
                }
            }
        });
        f.children('select').each(function () {
            var i = $(this);
            var rule = i.attr('data-rule');
            if (rule !== undefined) {
                var ierror = false;
                var pos = rule.indexOf(':', 0);
                if (pos >= 0) {
                    var exp = rule.substr(pos + 1, rule.length);
                    rule = rule.substr(0, pos);
                } else {
                    rule = rule.substr(pos + 1, rule.length);
                }
                switch (rule) {
                    case 'required':
                        if (i.val() === '') {
                            ferror = ierror = true;
                        }
                }
                if (ierror) {
                    i.addClass("form-error").next(".validation").html("This field is required").show();
                } else {
                    i.addClass("form-success");
                    i.removeClass("form-error").next(".validation").hide();
                }
            }
        });
        if (ferror) {
            return false;
        } else
            return true;
    }
};
