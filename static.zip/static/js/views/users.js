
$("#frmUpdateProfile").submit(function () {
    if (formValidator.validate($(this), ".form-group")) {
        $('.loader').show();
        $.post($(this).attr("action"), $(this).serialize(), function (resp) {
            $('.loader').hide();
            if (resp.status === 'ok') {
                utils.displaySuccessAlert(resp.message);
            } else if (resp.status === 'error') {
                utils.displayErrorAlert(resp.message);
            }
        });
    }
    return false;
});

$("#frmChangeUsername").submit(function(){
    if (formValidator.validate($(this), ".form-group")) {
        // $('.loader').show();
        // $.post($(this).attr("action"), $(this).serialize(), function (resp) {
        //     $('.loader').hide();
        //     if (resp.status === 'ok') {
        //         utils.displaySuccessAlert(resp.message);
        //     } else if (resp.status === 'error') {
        //         utils.displayErrorAlert(resp.message);
        //     }
        // });
    }
    return false;
});

$("#frmChangePassword").submit(function(){
    if (formValidator.validate($(this), ".form-group")) {
        // $('.loader').show();
        // $.post($(this).attr("action"), $(this).serialize(), function (resp) {
        //     $('.loader').hide();
        //     if (resp.status === 'ok') {
        //         utils.displaySuccessAlert(resp.message);
        //     } else if (resp.status === 'error') {
        //         utils.displayErrorAlert(resp.message);
        //     }
        // });
    }
    return false;
});