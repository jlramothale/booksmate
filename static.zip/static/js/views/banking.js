// alert("hello");
$("#frmAddBankAccount").submit(function(){
    if (formValidator.validate($(this), ".form-group")) {
        $('.loader').show();
        $.post($(this).attr("action"), $(this).serialize(), function (resp) {
            $('.loader').hide();
            if (resp.status === 'ok') {
                utils.displaySuccessAlert(resp.message);
            } else if (resp.status === 'error') {
                utils.displayErrorAlert(resp.message);
            }
        });
    }
    return false;
});

$("#frmSaveBankAccount").submit(function(){
    if (formValidator.validate($(this), ".form-group")) {
        $('.loader').show();
        $.post($(this).attr("action"), $(this).serialize(), function (resp) {
            $('.loader').hide();
            if (resp.status === 'ok') {
                utils.displaySuccessAlert(resp.message);
            } else if (resp.status === 'error') {
                utils.displayErrorAlert(resp.message);
            }
        });
    }
    return false;
});

$("#frmAddPettyCashAccount").submit(function(){
    if (formValidator.validate($(this), ".form-group")) {
        $('.loader').show();
        $.post($(this).attr("action"), $(this).serialize(), function (resp) {
            $('.loader').hide();
            if (resp.status === 'ok') {
                utils.displaySuccessAlert(resp.message);
            } else if (resp.status === 'error') {
                utils.displayErrorAlert(resp.message);
            }
        });
    }
    return false;
});

$("#frmAddDirectorAccount").submit(function(){
    if (formValidator.validate($(this), ".form-group")) {
        $('.loader').show();
        $.post($(this).attr("action"), $(this).serialize(), function (resp) {
            $('.loader').hide();
            if (resp.status === 'ok') {
                utils.displaySuccessAlert(resp.message);
            } else if (resp.status === 'error') {
                utils.displayErrorAlert(resp.message);
            }
        });
    }
    return false;
});