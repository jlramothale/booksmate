$(document).ready(function() {
    $('.datatables').DataTable({
        "pagingType": "full_numbers",
        "lengthMenu": [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
        responsive: true,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Search records",
        }
    });

    // make cursor to pointer on row hover
    $(".tr-click").hover(function(){
        $(this).css({
            "cursor": "pointer",
        });
        $(this).attr("title", "Edit")
    });
    // listen on row onclick event
    $(".tr-click").click(function(){
        utils.gotoPage($(this).attr("link"));
    });

});

// Company settings
$("#frmSaveCompany").submit(function(){
    if (formValidator.validate($(this), ".form-group")) {
        $('.loader').show();
        utils.handleDefaultRequest($(this).attr("action"), $(this).serialize());
    }
    return false;
});

$("#frmChangeCompanyLogo").submit(function(){
    if (formValidator.validate($(this), ".form-group")) {
        var data = new FormData($(this)[0]);
        $('.loader').show();
        $.ajax({
            type: "POST",
            url: $(this).attr("action"),
            data: data,
            contentType: false,
            cache: false,
            processData: false,
            success: function (resp) {
                utils.handleDefaultResponse(resp);
            }
        });
    }
    return false;
});

$("#frmAddRegistration").submit(function(){
    if (formValidator.validate($(this), ".form-group")) {
        $('.loader').show();
        utils.handleDefaultRequest($(this).attr("action"), $(this).serialize());
    }
    return false;
});

$(".frmEditRegistration").submit(function(){
    if (formValidator.validate($(this), ".form-group")) {
        $('.loader').show();
        utils.handleDefaultRequest($(this).attr("action"), $(this).serialize());
    }
    return false;
});

$(".frmDeleteRegistration").submit(function(){
    $('.loader').show();
    utils.handleDefaultRequest($(this).attr("action"), $(this).serialize());
    return false;
});

// Customers
$("#frmSaveCustomer").submit(function(){
    if (formValidator.validate($(this), ".form-group")) {
        $('.loader').show();
        utils.handleDefaultRequest($(this).attr("action"), $(this).serialize());
    }
    return false;
});

$("#frmDeleteCustomer").submit(function(){
    $('.loader').show();
    utils.handleDefaultRequest($(this).attr("action"), $(this).serialize());
    return false;
});

$("#frmActivateCustomer").submit(function(){
    $('.loader').show();
    utils.handleDefaultRequest($(this).attr("action"), $(this).serialize());
    return false;
});

$(".frmActivateCustomer").submit(function(){
    $('.loader').show();
    utils.handleDefaultRequest($(this).attr("action"), $(this).serialize());
    return false;
});

// Supplier settings
$("#frmSaveSupplier").submit(function(){
    if (formValidator.validate($(this), ".form-group")) {
        $('.loader').show();
        utils.handleDefaultRequest($(this).attr("action"), $(this).serialize());
    }
    return false;
});

$("#frmDeleteSupplier").submit(function(){
    $('.loader').show();
    utils.handleDefaultRequest($(this).attr("action"), $(this).serialize());
    return false;
});

$("#frmActivateSupplier").submit(function(){
    $('.loader').show();
    utils.handleDefaultRequest($(this).attr("action"), $(this).serialize());
    return false;
});

$(".frmActivateSupplier").submit(function(){
    $('.loader').show();
    utils.handleDefaultRequest($(this).attr("action"), $(this).serialize());
    return false;
});

// Products & Services
$("#frmAddProduct").submit(function(){
    if (formValidator.validate($(this), ".form-group")) {
        $('.loader').show();
        utils.handleDefaultRequest($(this).attr("action"), $(this).serialize());
    }
    return false;
});

$(".frmSaveProdict").submit(function(){
    if (formValidator.validate($(this), ".form-group")) {
        $('.loader').show();
        utils.handleDefaultRequest($(this).attr("action"), $(this).serialize());
    }
    return false;
});

$(".frmDeleteProduct").submit(function(){
    $('.loader').show();
    utils.handleDefaultRequest($(this).attr("action"), $(this).serialize());
    return false;
});

$("#frmAddService").submit(function(){
    if (formValidator.validate($(this), ".form-group")) {
        $('.loader').show();
        utils.handleDefaultRequest($(this).attr("action"), $(this).serialize());
    }
    return false;
});

$(".frmSaveService").submit(function(){
    if (formValidator.validate($(this), ".form-group")) {
        $('.loader').show();
        utils.handleDefaultRequest($(this).attr("action"), $(this).serialize());
    }
    return false;
});

$(".frmDeleteService").submit(function(){
    $('.loader').show();
    utils.handleDefaultRequest($(this).attr("action"), $(this).serialize());
    return false;
});


