
$("#frmRegister").submit(function () {
    $('.loader').show();
    $.post($(this).attr("action"), $(this).serialize(), function (resp) {
        $('.loader').hide();
        if (resp.status === 'ok') {
            utils.gotoPage(resp.message);
        } else if (resp.status === 'error') {
            utils.displayErrorAlert(resp.message);
        }
    });
    return false;
});

$("#frmLogin").submit(function () {
    $('.loader').show();
    $.post($(this).attr("action"), $(this).serialize(), function (resp) {
        $('.loader').hide();
        if (resp.status === 'ok') {
            utils.gotoPage(resp.message);
        } else if (resp.status === 'error') {
            utils.displayErrorAlert(resp.message);
        }
    });
    return false;
});

$("#frmCompleteUserRegistration").submit(function () {
    if (formValidator.validate($(this))) {
        if (formValidator.isEqualPasswords($("#password"), $("#repassword"))) {
            $('.loader').show();
            $.post($(this).attr("action"), $(this).serialize(), function (resp) {
                $('.loader').hide();
                if (resp.status === 'ok') {
                    utils.gotoPage(resp.message);
                } else if (resp.status === 'error') {
                    utils.displayErrorAlert(resp.message);
                }
            });
        }
    }
    return false;
});

$("#frmSendLink").submit(function () {
    $('.loader').show();
    $.post($(this).attr("action"), $(this).serialize(), function (resp) {
        $('.loader').hide();
        if (resp.status === 'ok') {
            utils.displaySuccessAlert(resp.message);
        } else if (resp.status === 'error') {
            utils.displayErrorAlert(resp.message);
        }
    });
    return false;
});

$("#frmResetPassword").submit(function () {
    $('.loader').show();
    $.post($(this).attr("action"), $(this).serialize(), function (resp) {
        $('.loader').hide();
        if (resp.status === 'ok') {
            utils.displaySuccessAlert(resp.message);
        } else if (resp.status === 'error') {
            utils.displayErrorAlert(resp.message);
        }
    });
    return false;
});