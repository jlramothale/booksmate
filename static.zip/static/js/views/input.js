$(document).ready(function() {
    $('#datatables').DataTable({
        "pagingType": "full_numbers",
        "lengthMenu": [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
        responsive: true,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Search records",
        }
    });

    var table = $('#datatable').DataTable();

    // Edit record
    table.on('click', '.edit', function() {
        $tr = $(this).closest('tr');
        var data = table.row($tr).data();
        alert('You press on Row: ' + data[0] + ' ' + data[1] + ' ' + data[2] + '\'s row.');
    });

    // Delete a record
    table.on('click', '.remove', function(e) {
        $tr = $(this).closest('tr');
        table.row($tr).remove().draw();
        e.preventDefault();
    });

    //Like record
    table.on('click', '.like', function() {
        alert('You clicked on Like button');
    });

    // make cursor to pointer on row hover
    $(".tr-click").hover(function(){
        $(this).css({
            "cursor": "pointer"
        });
        $(this).attr("title", "Edit Input")
    });
    // listen on row onclick event
    $(".tr-click").click(function(){
        utils.gotoPage("/input/edit-input/" + hash + "/" + $(this).attr("id") + "/");
    });

    $("#frmUploadDocument").submit(function () {
        if (formValidator.validate($(this), ".input-group")) {
            var data = new FormData($(this)[0]);
            $('.loader').show();
            $.ajax({
                type: "POST",
                url: $(this).attr("action"),
                data: data,
                contentType: false,
                cache: false,
                processData: false,
                success: function (resp) {
                    $('.loader').hide();
                    if (resp.status === 'ok') {
                        utils.gotoPage(resp.message);
                    } else if (resp.status === 'error') {
                        utils.displayErrorAlert(resp.message);
                    }
                }
            });
        }
        return false;
    });

    $("#frmSubmitInput").submit(function(){
        if (formValidator.validate($(this), ".form-group")) {
            $('.loader').show();
            $.post($(this).attr("action"), $(this).serialize(), function(resp) {
                $('.loader').hide();
                if (resp.status === 'ok') {
                    utils.gotoPage(resp.message);
                    // utils.displaySuccessAlert(resp.message);
                } else if (resp.status === 'error') {
                    utils.displayErrorAlert(resp.message);
                }
            });
        }
        return false;
    });

    $("#frmSaveInput").submit(function(){
        if (formValidator.validate($(this), ".form-group")) {
            $('.loader').show();
            $.post($(this).attr("action"), $(this).serialize(), function(resp) {
                $('.loader').hide();
                if (resp.status === 'ok') {
                    utils.displaySuccessAlert(resp.message);
                } else if (resp.status === 'error') {
                    utils.displayErrorAlert(resp.message);
                }
            });
        }
        return false;
    });
    
});


function decide_paid(select, input){
    if($(select).val() === "No"){
        do_paid_no(input);
    } else if($(select).val() === "Yes"){
        do_paid_yes(input);
    } else if($(select).val() === "Partly Paid"){
        do_paid_partly(input);
    }
}

function do_paid_no(date){
    $("#payment_method").prop('disabled', true);
    $("#cash_source").prop('disabled', true);
    $("#payment_date").val(increment_date(date, 30));
    $("#final_payment").html("");
}

function do_paid_yes(date){
    $('#payment_method').removeAttr("disabled");
    $('#cash_source').removeAttr("disabled");
    $("#payment_date").val(format_date(date));
    $("#final_payment").html("");
}

function do_paid_partly(date){
    $("#payment_method").prop('disabled', false);
    $("#cash_source").prop('disabled', false);
    $("#payment_date").val(format_date(date));
    final_date = increment_date(date, 30);
    var html = [];
    html.push('<p style="margin-bottom: -5px; font-weight: bold;">Final Payment Date</p>');
    html.push('<input type="date" id="final_payment_date" name="final_payment_date" value="'+final_date+'" class="form-control">');
    html.push('<span class="validation"></span>');
    $("#final_payment").html(html.join(""));
}

function decide_payment_method(select){
    var options = [];
    if($(select).val() === "Card Payment" || 
        $(select).val() === "EFT" ||
        $(select).val() === "Transfer"){
        $.post("/banking/get-accounts/", "type=bank&csrfmiddlewaretoken="+ csrftoken, function(resp) {
            var accounts = resp.message;
            for (i = 0; i < accounts.length; i++) { 
                options.push(
                    "<option value='"+accounts[i]+"'>"+accounts[i]+"</option>",
                );
            }
            $("#cash_source").html(options.join(""));
        });
    } else if($(select).val() === "Director Account"){
        $.post("/banking/get-accounts/", "type=director&csrfmiddlewaretoken="+ csrftoken, function(resp) {
            var accounts = resp.message;
            for (i = 0; i < accounts.length; i++) { 
                options.push(
                    "<option value='"+accounts[i]+"'>"+accounts[i]+"</option>",
                );
            }
            $("#cash_source").html(options.join(""));
        });
    } else if($(select).val() === "Cash Deposit"){
        $.post("/banking/get-accounts/", "type=cash&csrfmiddlewaretoken="+ csrftoken, function(resp) {
            var accounts = resp.message;
            for (i = 0; i < accounts.length; i++) { 
                options.push(
                    "<option value='"+accounts[i]+"'>"+accounts[i]+"</option>",
                );
            }
            $("#cash_source").html(options.join(""));
        });
    }
    
}

function get_accounts(options){
    
}

var c_u_var = {
    assign_value: function(select, input){
        $(input).val($(select).val());
        if($(select).attr("msg") === "transaction_date"){
            var data = "csrfmiddlewaretoken="+csrftoken+"&key=transaction_date&value="+$(select).val();
            c_u_var.set_ses_value(data); 
        }
    },
    set_ses_value: function(data){
        $.post("/input/set-session-values/", data, function( response ) {
            window.location.reload();
        });
    }
};

function increment_date(date, increment){
    var myDate = new Date(date);
    myDate.setDate(myDate.getDate() + increment);
    var y = myDate.getFullYear(),
        m = myDate.getMonth() + 1,
        d = myDate.getDate();
    var pad = function(val) { var str = val.toString(); return (str.length < 2) ? "0" + str : str};
    dateString = [y, pad(m), pad(d)].join("-");
    return dateString;
}

function format_date(date){
    var myDate = new Date(date);
    var y = myDate.getFullYear(),
        m = myDate.getMonth() + 1,
        d = myDate.getDate();
    var pad = function(val) { var str = val.toString(); return (str.length < 2) ? "0" + str : str};
    dateString = [y, pad(m), pad(d)].join("-");
    return dateString;
}
