$(document).ready(function() {
    $('.datatables').DataTable({
        "pagingType": "full_numbers",
        "lengthMenu": [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ],
        responsive: true,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Search records",
        }
    });

    // make cursor to pointer on row hover
    $(".tr-click").hover(function(){
        $(this).css({
            "cursor": "pointer",
        });
        $(this).attr("title", "Edit")
    });
    // listen on row onclick event
    $(".tr-click").click(function(){
        utils.gotoPage($(this).attr("link"));
    });

});

$("#frmNewCustomer").submit(function(){
    if (formValidator.validate($(this), ".form-group")) {
        $('.loader').show();
        $.post($(this).attr("action"), $(this).serialize(), function (resp) {
            $('.loader').hide();
            if (resp.status === 'ok') {
                utils.clearForm("#frmNewCustomer");
                utils.displaySuccessAlert(resp.message);
            } else if (resp.status === 'error') {
                utils.displayErrorAlert(resp.message);
            }
        });
    }
    return false;
});

$("#frmNewSupplier").submit(function(){
    if (formValidator.validate($(this), ".form-group")) {
        $('.loader').show();
        $.post($(this).attr("action"), $(this).serialize(), function (resp) {
            $('.loader').hide();
            if (resp.status === 'ok') {
                utils.clearForm("#frmNewSupplier");
                utils.displaySuccessAlert(resp.message);
            } else if (resp.status === 'error') {
                utils.displayErrorAlert(resp.message);
            }
        });
    }
    return false;
});