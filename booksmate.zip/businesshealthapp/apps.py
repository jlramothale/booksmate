from django.apps import AppConfig


class BusinesshealthappConfig(AppConfig):
    name = 'businesshealthapp'
