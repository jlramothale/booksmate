from django.urls import path
from . import views

app_name = "businesshealthapp"

urlpatterns = [
    path('', views.business_health, name="business-health"),
    # path('save-user/', views.save_user, name="save-user"),
    # path('change-username/', views.change_username, name='change-username'),
    # path('upload-image/', UploadImageView.as_view(), name='upload-image'),
    # path('change-password/', views.change_password, name='change-password')
]
