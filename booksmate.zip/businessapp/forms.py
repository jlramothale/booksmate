from django import forms
from .models import (
    Business, Registrations, Supplier, Product, Service
)

class BuisnessForm(forms.ModelForm):
    name = forms.CharField(max_length=256, label="Company name * ", required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    reg_number = forms.CharField(max_length=256, label="Reg No. * ", required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    year_end = forms.CharField(max_length=256, label="Year End * ", required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    email = forms.EmailField(max_length=256, label="Email Address * ", required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    office_number = forms.CharField(max_length=256, label="Office Number * ", required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    website = forms.CharField(max_length=256, label="Website * ", required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))

    class Meta:
        model = Business
        fields = [
            "name", "reg_number", "year_end", 
            "email", "office_number", "website",
        ]

class BusilessLogoForm(forms.ModelForm):
    logo = forms.FileField(label="Select Picture * ", required=False, widget=forms.FileInput(attrs={'class':'form-control', 'data-rule':'required'}))

    class Meta:
        model = Business
        fields = ["logo"]

class RegistrationsForm(forms.ModelForm):
    institution = forms.CharField(max_length=256, label="Institution * ", required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    registration = forms.CharField(max_length=256, label="Registratioon. * ", required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    reg_number = forms.CharField(max_length=256, label="Reg Number * ", required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
   
    class Meta:
        model = Registrations
        fields = [
            "institution", "registration", "reg_number"
        ]

class ProductForm(forms.ModelForm):
    sku = forms.CharField(max_length=128, label="SKU", required=False, widget=forms.TextInput(attrs={'class':'form-control',}))
    name = forms.CharField(max_length=256, label="Name * ", required=False, widget=forms.TextInput(attrs={'class':'form-control', 'data-rule':'required'}))
    selling_price = forms.CharField(max_length=64, label="Selling Price (R) * ", required=False, widget=forms.TextInput(attrs={'class':'form-control', 'data-rule':'required'}))
    cost_price = forms.CharField(max_length=64, label="Cost Price (R) * ", required=False, widget=forms.TextInput(attrs={'class':'form-control', 'data-rule':'required'}))
    description = forms.CharField(label="Description ", required=False, widget=forms.Textarea(attrs={'class':'form-control', 'rows':2}))

    class Meta:
        model = Product
        fields = ["sku", "name", "selling_price", "cost_price", "description"]

class ServiceForm(forms.ModelForm):
    name = forms.CharField(max_length=256, label="Name * ", required=False, widget=forms.TextInput(attrs={'class':'form-control', 'data-rule':'required'}))
    selling_price = forms.CharField(max_length=64, label="Selling Price (R) * ", required=False, widget=forms.TextInput(attrs={'class':'form-control', 'data-rule':'required'}))
    cost_price = forms.CharField(max_length=64, label="Cost Price (R) * ", required=False, widget=forms.TextInput(attrs={'class':'form-control', 'data-rule':'required'}))
    description = forms.CharField(label="Description ", required=False, widget=forms.Textarea(attrs={'class':'form-control', 'rows':2}))

    class Meta:
        model = Service
        fields = ["name", "selling_price", "cost_price", "description"]

class SupplierForm(forms.ModelForm):
    name = forms.CharField(max_length=256, label="Supplier name * ", required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    reg_number = forms.CharField(max_length=256, label="Registration No. ", required=False, widget=forms.TextInput(attrs={'class':'form-control',}))
    vat_number = forms.CharField(max_length=256, label="Vat No. ", required=False, widget=forms.TextInput(attrs={'class':'form-control',}))
    tax_ref_number = forms.CharField(max_length=256, label="Tax Ref No.",required=False, widget=forms.TextInput(attrs={'class':'form-control',}))
    sup_office_number = forms.CharField(max_length=256, label="Office Number *", required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    sup_office_email = forms.CharField(max_length=256, label="Office Email *", required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    con_person = forms.CharField(max_length=256, label="Contact Person *", required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    con_person_number = forms.CharField(max_length=256, label="Contact Person No.* ", required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    street_address = forms.CharField(max_length=256, label="Street Address", required=False, widget=forms.TextInput(attrs={'class':'form-control',}))
    town_city = forms.CharField(max_length=256, label="City ", required=False, widget=forms.TextInput(attrs={'class':'form-control',}))
    province = forms.CharField(max_length=256, label="Province ", required=False, widget=forms.TextInput(attrs={'class':'form-control col-6',}))
    postal_code = forms.CharField(max_length=256, label="Postal Code ", required=False, widget=forms.TextInput(attrs={'class':'form-control col-6',}))

    class Meta:
        model = Supplier
        fields = ["name", "reg_number", "vat_number", 
            "tax_ref_number", "sup_office_number", "sup_office_email",
            "con_person", "con_person_number", "street_address",
            "town_city", "province", "postal_code"
        ]