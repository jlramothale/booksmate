from django.apps import AppConfig


class BusinessappConfig(AppConfig):
    name = 'businessapp'
