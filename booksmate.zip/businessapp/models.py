from django.db import models
from django.utils import timezone
from usersapp.models import Account, User
from systemapp.models import (
    Currency
)
from inputapp.models import Upload, Input
from booksmate import utils

def business_logo_path(instance, filename):
    return 'businesses/{0}/{1}'.format(instance.id, filename)

class Business(models.Model):
    account = models.ForeignKey(Account, blank=True, null=True, on_delete=models.SET_NULL)
    name = models.CharField(max_length=256, default='', blank=True, null=True)
    reg_number = models.CharField(max_length=128, default='', blank=True, null=True)
    reg_type = models.CharField(max_length=128, default='', blank=True, null=True)
    year_end = models.CharField(max_length=64, default='', blank=True, null=True)
    currency = models.ForeignKey(Currency, blank=True, null=True, on_delete=models.SET_NULL)

    email = models.EmailField(blank=True, null=True)
    office_number = models.CharField(max_length=16, default='', blank=True, null=True)
    
    website = models.CharField(max_length=128, default='', blank=True, null=True)
    sector = models.CharField(max_length=128, default='', blank=True, null=True)
    industry = models.CharField(max_length=128, default='', blank=True, null=True)
    logo = models.FileField(upload_to=business_logo_path, blank=True, null=True)
    date_added = models.DateTimeField(default=timezone.now, blank=True, null=True)
    date_deleted = models.DateTimeField(default=timezone.now, blank=True, null=True)
    deleted = models.BooleanField(default=False)
    
    class Meta:
        verbose_name_plural = "Business"
    
    def __str__(self):
        return self.name

# vat_number = models.CharField(max_length=128, default='', blank=True, null=True)
# tax_ref_number = models.CharField(max_length=128, default='', blank=True, null=True)
class Registrations(models.Model):
    business = models.ForeignKey(Business, blank=True, null=True, on_delete=models.SET_NULL)
    institution = models.CharField(max_length=128, default='', blank=True, null=True) # SARS
    registration = models.CharField(max_length=128, default='', blank=True, null=True) # Income Tax
    reg_number = models.CharField(max_length=128, default='', blank=True, null=True) # 123456789
    date_added = models.DateTimeField(default=timezone.now, blank=True, null=True)
    date_deleted = models.DateTimeField(default=timezone.now, blank=True, null=True)
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name_plural = "Registrations"
    
    def __str__(self):
        return f"{self.registration}: {self.reg_number}"


class PhysicalAddress(models.Model):
    business = models.OneToOneField(Business, blank=True, null=True, on_delete=models.SET_NULL)
    street_address1 = models.CharField(max_length=512, default='', blank=True, null=True)
    street_address2 = models.CharField(max_length=512, default='', blank=True, null=True)
    town_city = models.CharField(max_length=512, default='', blank=True, null=True)
    province = models.CharField(max_length=128, default='', blank=True, null=True)
    postal_code = models.CharField(max_length=512, default='', blank=True, null=True)
    country = models.CharField(max_length=128, default='', blank=True, null=True)
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name_plural = "PhysicalAddress"
    
    def __str__(self):
        return self.street_address1

class PostalAddress(models.Model):
    business = models.OneToOneField(Business, blank=True, null=True, on_delete=models.SET_NULL)
    street_address1 = models.CharField(max_length=512, default='', blank=True, null=True)
    street_address2 = models.CharField(max_length=512, default='', blank=True, null=True)
    town_city = models.CharField(max_length=512, default='', blank=True, null=True)
    province = models.CharField(max_length=128, default='', blank=True, null=True)
    postal_code = models.CharField(max_length=512, default='', blank=True, null=True)
    country = models.CharField(max_length=128, default='', blank=True, null=True)
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name_plural = "PostalAddress"
    
    def __str__(self):
        return self.street_address1

class BankAccount(models.Model):
    account = models.ForeignKey(Account, blank=True, null=True, on_delete=models.SET_NULL)
    business = models.ForeignKey(Business, blank=True, null=True, on_delete=models.SET_NULL)
    bank_name = models.CharField(max_length=128, default='', blank=True, null=True)
    account_holder = models.CharField(max_length=215, default='', blank=True, null=True)
    account_number = models.CharField(max_length=128, default='', blank=True, null=True)
    masked_acc_number = models.CharField(max_length=128, default='', blank=True, null=True)
    account_type = models.CharField(max_length=128, default='', blank=True, null=True)
    branch_name = models.CharField(max_length=128, default='', blank=True, null=True)
    branch_code = models.CharField(max_length=64, default='', blank=True, null=True)
    linked = models.CharField(max_length=64, default='', blank=True, null=True)
    link_id = models.CharField(max_length=64, default='', blank=True, null=True)
    curren_balance = models.CharField(max_length=64, default='', blank=True, null=True)
    available_balance = models.CharField(max_length=64, default='', blank=True, null=True)
    date_linked = models.CharField(max_length=64, default='', blank=True, null=True)
    date_un_linked = models.CharField(max_length=64, default='', blank=True, null=True)
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name_plural = "BankAccounts"
    
    def __str__(self):
        return self.account_holder

class PettyCashAccount(models.Model):
    account = models.ForeignKey(Account, blank=True, null=True, on_delete=models.SET_NULL)
    business = models.ForeignKey(Business, blank=True, null=True, on_delete=models.SET_NULL)
    description = models.CharField(max_length=215, default='Petty Cash', blank=True, null=True)
    name = models.CharField(max_length=215, default='', blank=True, null=True)
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name_plural = "PettyCashAccount"
    
    def __str__(self):
        return self.bank.code

class DirectorAccount(models.Model):
    account = models.ForeignKey(Account, blank=True, null=True, on_delete=models.SET_NULL)
    business = models.ForeignKey(Business, blank=True, null=True, on_delete=models.SET_NULL)
    director_name = models.CharField(max_length=215, default='', blank=True, null=True)
    name = models.CharField(max_length=215, default='', blank=True, null=True)
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name_plural = "DirectorAccounts"
    
    def __str__(self):
        return self.bank.code

class Product(models.Model):
    account = models.ForeignKey(Account, blank=True, null=True, on_delete=models.SET_NULL)
    sku = models.CharField(max_length=128, default='', blank=True, null=True)
    name = models.CharField(max_length=256, default='', blank=True, null=True)
    selling_price = models.CharField(max_length=64, default='', blank=True, null=True)
    cost_price = models.CharField(max_length=64, default='', blank=True, null=True)
    tax = models.CharField(max_length=256, default='', blank=True, null=True)
    description = models.CharField(max_length=1024, null=True, default='', blank=True)
    date_added = models.DateTimeField(default=timezone.now, blank=True, null=True)
    date_deleted = models.DateTimeField(default=timezone.now, blank=True, null=True)
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name_plural = "Products"
    
    def __str__(self):
        return self.name

    def get_tax_value(self):
        tax_percent = self.tax / utils.Constants.PERCENT_HUNDRED
        return self.selling_price * tax_percent

class Service(models.Model):
    account = models.ForeignKey(Account, blank=True, null=True, on_delete=models.SET_NULL)
    name = models.CharField(max_length=256, default='', blank=True, null=True)
    selling_price = models.CharField(max_length=64, default='', blank=True, null=True)
    cost_price = models.CharField(max_length=64, default='', blank=True, null=True)
    tax = models.CharField(max_length=256, default='', blank=True, null=True)
    description = models.CharField(max_length=1024, null=True, default='', blank=True)
    date_added = models.DateTimeField(default=timezone.now, blank=True, null=True)
    date_removed = models.DateTimeField(default=timezone.now, blank=True, null=True)
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name_plural = "Services"
    
    def __str__(self):
        return self.name

    def get_tax_value(self):
        tax_percent = self.tax / utils.Constants.PERCENT_HUNDRED
        return self.selling_price * tax_percent

class Supplier(models.Model):
    account = models.ForeignKey(Account, blank=True, null=True, on_delete=models.SET_NULL)
    name = models.CharField(max_length=256, default='', blank=True, null=True)
    reg_number = models.CharField(max_length=128, default='', blank=True, null=True)
    vat_number = models.CharField(max_length=128, default='', blank=True, null=True)
    tax_ref_number = models.CharField(max_length=128, default='', blank=True, null=True)
    sup_office_number = models.CharField(max_length=24, default='', blank=True, null=True)
    sup_office_email = models.EmailField(blank=True, null=True)
    con_person = models.CharField(max_length=215, default='', blank=True, null=True)
    con_person_number = models.CharField(max_length=24, default='', blank=True, null=True)
    street_address = models.CharField(max_length=1024, default='', blank=True, null=True)
    town_city = models.CharField(max_length=512, default='', blank=True, null=True)
    province = models.CharField(max_length=128, default='', blank=True, null=True)
    postal_code = models.CharField(max_length=512, default='', blank=True, null=True)
    deleted = models.BooleanField(default=False)
    
    class Meta:
        verbose_name_plural = "Suppliers"
    
    def __str__(self):
        return self.name

class SupplierData(models.Model):
    supplier = models.OneToOneField(Supplier, blank=True, null=True, on_delete=models.SET_NULL)
    upload = models.OneToOneField(Upload, blank=True, null=True, on_delete=models.SET_NULL)

    class Meta:
        verbose_name_plural = "SupplierData"
    
    def __str__(self):
        return self.supplier.name

class SupplierInvoice(models.Model):
    supplier = models.ForeignKey(Supplier, blank=True, null=True, on_delete=models.SET_NULL)
    business = models.ForeignKey(Business, blank=True, null=True, on_delete=models.SET_NULL)
    invoice_type = models.CharField(max_length=128, default='', blank=True, null=True)
    invoice_number = models.CharField(max_length=128, default='', null=True)
    invoice_date = models.CharField(max_length=128, default='', blank=True, null=True)
    paid = models.CharField(max_length=64, default='', null=True)
    payment_method = models.CharField(max_length=128, default='', null=True)
    cash_source = models.CharField(max_length=128, default='', null=True)
    payment_date = models.CharField(max_length=128, default='', null=True)
    final_payment = models.CharField(max_length=128, default='', null=True)
    deleted = models.BooleanField(default=False)
    
    class Meta:
        verbose_name_plural = "SupplierInvoice"
    
    def __str__(self):
        return self.name

class InvoiceData(models.Model):
    invoice = models.OneToOneField(Supplier, blank=True, null=True, on_delete=models.SET_NULL)
    input = models.OneToOneField(Input, blank=True, null=True, on_delete=models.SET_NULL)

    class Meta:
        verbose_name_plural = "InvoiceData"
    
    def __str__(self):
        return self.supplier.name

class InvoiceItem(models.Model):
    supplier_invoice = models.ForeignKey(SupplierInvoice, blank=True, null=True, on_delete=models.SET_NULL)
    description = models.CharField(max_length=128, default='', blank=True, null=True)
    quantity = models.CharField(max_length=128, default='')
    amount = models.CharField(max_length=16, default='', blank=True, null=True)
    total = models.EmailField(blank=True, null=True)
    deleted = models.BooleanField(default=False)
    
    class Meta:
        verbose_name_plural = "InvoiceItems"
    
    def __str__(self):
        return self.invoice

class PurchaseJournal(models.Model):
    business = models.ForeignKey(Business, blank=True, null=True, on_delete=models.SET_NULL)
    input = models.ForeignKey(Input, blank=True, null=True, on_delete=models.SET_NULL)
    date = models.CharField(max_length=128, default='', null=True) # trans date
    ref = models.CharField(max_length=128, default='', null=True) # invoice number
    tax_entry = models.CharField(max_length=256, default='Inclusive', null=True)
    description = models.TextField(default='', blank=True, null=True,)
    amount = models.CharField(max_length=256, default='', null=True)
    # comes from category, which is chart of accounts
    debit = models.CharField(max_length=256, default='', null=True) 
    # bank source being credited
    credit = models.CharField(max_length=256, default='', null=True) 
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name_plural = "PurchaseJournal"

class TrialBalance(models.Model):
    business = models.ForeignKey(Business, blank=True, null=True, on_delete=models.SET_NULL)
    input = models.ForeignKey(Input, blank=True, null=True, on_delete=models.SET_NULL)
    type = models.CharField(max_length=64, default='', null=True)
    # chart of accounts id
    account = models.CharField(max_length=128, default='', null=True)
    # debit or credit description
    description = models.CharField(max_length=256, default='', null=True)
    # actual money debit for a purchase
    debit = models.CharField(max_length=128, default='', null=True)
    # actual money credited from a bank source
    credit = models.CharField(max_length=128, default='', null=True)
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name_plural = "TrialBalance"

class IncomeStatementCOA(models.Model):
    pass

class BalanceSheetCOA(models.Model):
    pass