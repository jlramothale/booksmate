"""
Utils: System various shared utilities

Copyright (c) 2019 Bonmas Consultants
Licensed under the MIT license <http://www.opensource.org/licenses/mit-license.php>

@author Johannes Ramothale <johannes@star-x.co.za>
@since 05 Oct 2016, 7:05:58 AM
@version 1.0
"""

from django.http import JsonResponse
from booksmate import settings
import random, string
from django.utils import timezone
from usersapp.models import Account, User, Log
from django.core.mail import send_mail
from django.utils import formats
import hashlib
import magic

""" Returns a json response """
def response(status, message):
    return JsonResponse({"status": status, "message": message})

""" Generate a random string of letters and digits """
def random_string_digit(length=10):
    key_space = string.ascii_letters + string.digits
    return ''.join(random.choice(key_space) for i in range(length))

""" Generate a random string of letters """
def random_string(length=10):
    key_space = string.ascii_letters
    return ''.join(random.choice(key_space) for i in range(length))

""" Generate a random number """
def random_number(first=1, last=10):
    return random.randint(first, last)

""" Log user action """
def log_user(user, action):
    log = Log(user=user, action=action)
    log.save()

""" Log system action """
def log_system(action):
    pass

""" Returns a user access agent/client imformation. i.e. browser or app """
def get_user_agent(request):
    return request.META['HTTP_USER_AGENT']

""" Returns a random hashed string """
def get_hash(request):
    hash_string = get_user_agent(request) + random_string_digit()
    return hashlib.sha256(hash_string.encode()).hexdigest()

""" Return formatted date """
def date_format(date):
    return formats.date_format(date, "DATE_FORMAT")

""" Return formatted time """
def time_format(date):
    return formats.date_format(date, "TIME_FORMAT")

""" Return formatted datetime """
def short_date_format(date):
    return formats.date_format(date, "SHORT_DATETIME_FORMAT")

""" Generate user id """
def generate_user_id():
    count = User.objects.count() + 1
    user_id = f"{timezone.now().year}{random_number(0,9)}"
    user_id += f"{timezone.now().month}{random_number(0,9)}"
    user_id += f"{timezone.now().day}{random_number(0,9)}"
    user_id += str(count)
    diff = Constants.USER_ID_LENGHT - len(user_id)
    for i in range(diff):
        user_id = "0" + user_id
    return user_id

""" Generate account id """
def generate_account_id():
    count = Account.objects.count() + 1
    account_id = f"{timezone.now().year}{random_number(0,9)}"
    account_id += f"{timezone.now().month}{random_number(0,9)}"
    account_id += f"{timezone.now().day}{random_number(0,9)}"
    account_id += str(count)
    diff = Constants.ACCOUNT_ID_LENGHT - len(account_id)
    for i in range(diff):
        account_id = "0" + account_id
    return account_id

""" Returns media mime type """
def get_mime_type(file):
    mime = magic.Magic(mime=True)
    return mime.from_file(file)

""" Returns true if file is PDF """
def is_file_pdf(file):
    mime = get_mime_type(file)
    if mime is "application/pdf":
        return True
    return False

""" Returns true is file is an Image """
def is_file_image(file):
    mime = get_mime_type(file)
    if mime is "image/jpg":
        return True
    if mime is "image/jpeg":
        return True
    if mime is "image/png":
        return True
    return False

""" Returns file image type; either PDF or Image """
def get_file_type(file):
    if is_file_pdf(file):
        return "pdf"
    elif is_file_image(file):
        return "img"
    else:
        return None

""" Prepare AWS OCR data: return words data """
def make_words_data(document):
    res_dict = {}
    for page in document.pages:
        for l, line in enumerate(page.lines):
            for w, word in enumerate(line.words):
                res_dict.update({f"word{l}" : word.text})
    return res_dict

""" Prepare AWS OCR data: return lines data """
def make_lines_data(document):
    res_dict = {}
    for page in document.pages:
        for l, line in enumerate(page.lines):
            res_dict.update({f"line{l}" : line.text})
    return res_dict

""" Prepare AWS OCR data: return form data """
def make_form_data(document):
    res_dict = {}
    for page in document.pages:
        for field in page.form.fields:
            res_dict.update({f"{field.key}" : "{}".format(field.value)})
    return res_dict

""" Prepare AWS OCR data: return table data """
def make_table_data(document):
    res_dict = {}
    for page in document.pages:
        table_index = 1
        for t, table in enumerate(page.tables):
            res_dict.update({"table" : t})
            for r, row in enumerate(table.rows):
                in_row = []
                for c, cell in enumerate(row.cells):
                    in_row.append(cell.text)
                res_dict.update({f"row{r}" : in_row})
    return res_dict

""" Send email """
def email(subject, from_email, recipient_list, message, html_message):
    send_mail(subject=subject, message=message, from_email=from_email, 
        recipient_list=recipient_list, html_message=html_message)

""" Constants """
class Constants:
    """ user_id generation length """
    USER_ID_LENGHT = 15

    """ account_id generation length """
    ACCOUNT_ID_LENGHT = 15

    """ ticket generation length """
    TICKET_LENGHT = 12

    PERCENT_HUNDRED = 100

""" Messages """
USER_DO_NOT_EXIST_MSG = "User does not exists"
USER_CREATES_MSG = "New user created: {0}"
LOGGED_IN_MSG = "Logged in"
LOGGED_OUT_MSG = "Logged out"
LOGIN_ERROR_MSG = "Invalid username or password"
INVALID_REQUEST_MSG = "Invalid request"
OK_TAG = "ok"
OK_MSG = "Operation Successful!"
ERROR_TAG = "error"
ERROR_MSG = "There seems to be a problem. Please try again later."
INVALID_PASSWORD_MSG = "Invalid current password: {0}"
USERNAME_EXISTS_MSG = "Username: {0} is already taken"
PASSWORD_MIS_MATCH_MSG = "Passwords do not match"
FEEDBACK_CREATED_MSG = "You feedback has been received, and we appreciate your honesty. We will use your information to make MyAdminPal you will love."
RESET_LINK_SENT_MSG = "Congratulations, we have emailed you instructions to help you reset your password."
RESET_PASS_ERROR_MSG = "User with username <strong>{0}</strong> does not exists. Could not reset password this time."
RESET_SUCC_MSG = "Password successfully changed. You can now proceed to login"