from django.urls import path
from . import views

app_name = "inputapp"

urlpatterns = [
    path('', views.input, name="input"),
    path('edit-input/<str:hash>/<int:id>/', views.edit_input, name="edit-input"),
    path('save-input/', views.save_input, name="save-input"),
    path('submit-input-batch', views.submit_input_batch, name="submit-input-batch"),

    path('upload/', views.upload, name="upload"),
    path('process-upload/<int:id>/', views.process_upload, name="process-upload"),
    path('submit-upload/', views.submit_upload, name="submit-upload"),

    path('scan/', views.scan, name="scan"),
    path('email/', views.email, name="email"),
    
]
