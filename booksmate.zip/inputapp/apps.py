from django.apps import AppConfig


class InputappConfig(AppConfig):
    name = 'inputapp'
