from django import forms
from .models import Upload, Input

class UploadForm(forms.ModelForm):
    document = forms.FileField(label="Select document to upload (pdf/image)", widget=forms.FileInput(attrs={'class':'form-control '}))
    
    class Meta:
        model = Upload
        fields = ["document"]

    def __init__(self, *args, **kwargs):
        super(UploadForm, self).__init__(*args, **kwargs)
        for field_key in self.fields:
            self.fields[field_key].label_suffix = ""

class InputForm(forms.ModelForm):
    document_type = forms.CharField(max_length=128, required=False, widget=forms.TextInput())
    invoice_number = forms.CharField(max_length=128, required=False, widget=forms.TextInput())
    transaction_date = forms.CharField(max_length=128, required=False, widget=forms.TextInput())
    total_amount = forms.CharField(max_length=256, required=False, widget=forms.TextInput())
    tax_rate = forms.CharField(max_length=256, required=False, widget=forms.TextInput())
    description = forms.CharField(required=False, widget=forms.Textarea())
    supplier_name = forms.CharField(max_length=512, required=False, widget=forms.TextInput())
    category = forms.CharField(max_length=256, required=False, widget=forms.TextInput())
    paid = forms.CharField(max_length=64, required=False, widget=forms.TextInput())
    payment_method = forms.CharField(max_length=128, required=False, widget=forms.TextInput())
    cash_source = forms.CharField(max_length=128, required=False, widget=forms.TextInput())
    payment_date = forms.CharField(max_length=128, required=False, widget=forms.TextInput())
    final_payment = forms.CharField(max_length=128, required=False, widget=forms.TextInput())

    class Meta:
        model = Input
        fields = [
            "document_type", "invoice_number", "transaction_date", 
            "total_amount", "tax_rate", "description", "supplier_name", "category", 
            "paid", "payment_method", "cash_source", "payment_date", "final_payment"
        ]

    def __init__(self, *args, **kwargs):
        super(InputForm, self).__init__(*args, **kwargs)
        for field_key in self.fields:
            self.fields[field_key].label_suffix = ""