from django.db import models
from django.utils import timezone
from usersapp.models import User, Account

class Upload(models.Model):
    account = models.ForeignKey(Account, blank=True, null=True, on_delete=models.SET_NULL)
    user = models.ForeignKey(User, blank=True, null=True, on_delete=models.SET_NULL)
    source = models.CharField(max_length=128, default='website', null=True, blank=True,)
    type = models.CharField(max_length=64, default='img', null=True, blank=True,)
    document = models.FileField(upload_to='documents', blank=True, null=True)
    upload_date = models.DateTimeField(default=timezone.now, null=True)
    deleted = models.BooleanField(default=False, null=True)

    class Meta:
        verbose_name_plural = "Uploads"

    def __str__(self):
        return self.type

class UploadData(models.Model):
    upload = models.ForeignKey(Upload, blank=True, null=True, on_delete=models.SET_NULL)
    raw_results = models.TextField(default='', blank=True, null=True,)
    words_data = models.TextField(default='', blank=True, null=True,)
    lines_data = models.TextField(default='', blank=True, null=True,)
    form_data = models.TextField(default='', blank=True, null=True,)
    table_data = models.TextField(default='', blank=True, null=True,)
    deleted = models.BooleanField(default=False, null=True)

    class Meta:
        verbose_name_plural = "UploadData"

    def __str__(self):
        return self.upload.type

class Input(models.Model):
    account = models.ForeignKey(Account, blank=True, null=True, on_delete=models.SET_NULL)
    user = models.ForeignKey(User, blank=True, null=True, on_delete=models.SET_NULL)
    upload = models.ForeignKey(Upload, blank=True, null=True, on_delete=models.SET_NULL)
    document_type = models.CharField(max_length=128, default='', null=True)
    invoice_number = models.CharField(max_length=128, default='', null=True)
    transaction_date = models.CharField(max_length=128, default='', null=True)
    total_amount = models.CharField(max_length=256, default='', null=True)
    tax_rate = models.CharField(max_length=256, default='', null=True)
    description = models.TextField(default='', blank=True, null=True,)
    supplier_name = models.CharField(max_length=512, default='', null=True)
    category = models.CharField(max_length=256, default='', null=True)
    paid = models.CharField(max_length=64, default='', null=True)
    payment_method = models.CharField(max_length=128, default='', null=True)
    cash_source = models.CharField(max_length=128, default='', null=True)
    payment_date = models.CharField(max_length=128, default='', null=True)
    final_payment = models.CharField(max_length=128, default='', null=True)
    deleted = models.BooleanField(default=False, null=True)

    class Meta:
        verbose_name_plural = "Input"

    def __str__(self):
        return "{}: {}".format(self.document_type, self.invoice_number)
