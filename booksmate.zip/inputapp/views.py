from django.shortcuts import render, redirect
from booksmate import settings, utils
from django.db import transaction
from django.contrib.auth.decorators import login_required
from . import ocr_core, trp, ppe
from .models import (
    Upload, UploadData, Input
)
from .forms import (
    UploadForm, InputForm
)
from businessapp.models import ( 
    Business, BankAccount, PettyCashAccount, DirectorAccount,
    Supplier, SupplierData, PurchaseJournal, TrialBalance
)
from usersapp.models import Account, User
from systemapp.models import TaxRate, PaymentMethod
import json

# Create your views here.
@login_required(login_url='/auth/login/')
def input(request):
    account = Account.objects.get(pk=request.session["account_id"])
    context = {
        "page": "input",
        "hash": utils.get_hash(request),
        "inputs": Input.objects.filter(account=account)
    }
    return render(request, "inputapp/input.html", context)

@login_required(login_url='/auth/login/')
def edit_input(request, hash, id):
    input = Input.objects.get(pk=id)
    context = {
        "page": "input",
        "input" : input,
    }
    return render(request, "inputapp/edit_input.html", context)

@login_required(login_url='/auth/login/')
def save_input(request):
    if request.method == "POST":
        post_copy = request.POST.copy()
        input = Input.objects.get(pk=post_copy.get("input_id"))
        form = InputForm(data=request.POST, instance=input)
        if form.is_valid():
            try:
                with transaction.atomic():
                    input = form.save()
                    input.save()

                    purchase = PurchaseJournal.objects.get(input=input)           
                    purchase.date = input.transaction_date
                    purchase.ref = input.invoice_number
                    purchase.tax_entry = purchase.tax_entry
                    purchase.description = input.description
                    purchase.amount = input.total_amount
                    purchase.debit = input.category
                    purchase.credit = input.cash_source
                    purchase.save()

                    # append gtrial balanace and attached extracted input
                    trial_debit = TrialBalance.objects.get(input=input, type="debit")
                    trial_debit.account = trial_debit.account
                    trial_debit.description = input.category
                    trial_debit.debit = input.total_amount
                    trial_debit.save()
                    
                    trial_credit = TrialBalance.objects.get(input=input, type="credit")
                    trial_credit.account = trial_credit.account
                    trial_credit.description = input.cash_source
                    trial_credit.credit = input.total_amount
                    trial_credit.save()

                    utils.log_user(request.user, "Updated inputs")
                    return utils.response(utils.OK_TAG, utils.OK_MSG)
            except Exception as e:
                transaction.rollback()
                return utils.response(utils.ERROR_TAG, str(e))
        else:
            error = ""
            for msg in form.errors:
                error += "{}.<br/>".format(msg)
            return utils.response(utils.ERROR_TAG, error)
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

@login_required(login_url='/auth/login/')
def submit_input_batch(request):
    pass

@login_required(login_url='/auth/login/')
def upload(request):
    if request.method == "POST":
        form = UploadForm(files=request.FILES)
        account = Account.objects.get(pk=request.session["account_id"])
        if form.is_valid():
            try:
                with transaction.atomic():
                    upload = form.save()
                    upload.account = account
                    upload.user = request.user
                    upload.type = utils.get_file_type(upload.document.path)

                    upload.save()

                    b_img = ocr_core.get_binary_image(upload.document.path)
                    response = ocr_core.analyze_all(b_img)

                    document = trp.Document(response)
                    words_data = utils.make_words_data(document)
                    lines_data = utils.make_lines_data(document)
                    form_data = utils.make_form_data(document)
                    table_data = utils.make_table_data(document)

                    UploadData.objects.create(
                        upload=upload, 
                        raw_results=str(response),
                        words_data=str(words_data),
                        lines_data=str(lines_data),
                        form_data=str(form_data), 
                        table_data=str(table_data),
                    )
                    utils.log_user(request.user, "Upload input document")
                    return utils.response(utils.OK_TAG, "/input/process-upload/{}/".format(upload.id))
            except Exception as e:
                transaction.rollback()
                return utils.response(utils.ERROR_TAG, str(e))
        else:
            error = ""
            for msg in form.errors:
                error += "{}.<br/>".format(msg)
            return utils.response(utils.ERROR_TAG, error)
    else:
        context = {
            "page": "input",
            "uploads": Upload.objects.all()
        }
        return render(request, "inputapp/upload.html", context)

@login_required(login_url='/auth/login/')
def process_upload(request, id):
    upload = Upload.objects.get(pk=id)
    upload_data = UploadData.objects.filter(upload=upload)

    words_data = json.loads(upload_data[0].words_data.replace("'", "\""))
    lines_data = json.loads(upload_data[0].lines_data.replace("'", "\""))
    form_data = json.loads(upload_data[0].form_data.replace("'", "\""))
    table_data = json.loads(upload_data[0].table_data.replace("'", "\""))
    
    doc_type = ppe.DocumentType(lines_data)
    inv_number = ppe.InvoiceNumber(form_data)
    trans_date = ppe.TransactionDate(form_data)
    totals = ppe.TotalAmount(form_data)
    supplier = ppe.SupplierName(lines_data)

    account = Account.objects.get(pk=request.session["account_id"])
    suppliers = Supplier.objects.filter(account=account)

    l_c_words = ppe.CleanInputs.clean_lines(lines_data, "chars")

    dates = trans_date.get_only_dates(words_data)
    amounts = totals.get_only_amounts(words_data, form_data)
    inv_words = inv_number.get_only_words(form_data, words_data)
    sup_names = supplier.get_poosible_sup_names(lines_data)

    # if doc_type.get_document_type() is not None:
    request.session["document_type"] = doc_type.get_document_type()
    # if inv_number.get_invoice_number() is not None:
    request.session["invoice_number"] = inv_number.get_invoice_number()
    # if trans_date.get_transaction_date() is not None:
    request.session["transaction_date"] = trans_date.get_transaction_date()
    # if totals.get_total_amount() is not None:
    request.session["total_amount"] = totals.get_total_amount()
    request.session["supplier_name"] = supplier.get_supplier_name(suppliers)

    context = {
        "page": "input",
        "upload" : upload,
        "tax_rates" : TaxRate.objects.all(),
        "payment_methods": PaymentMethod.objects.all(),
        "l_c_words": l_c_words,
        "dates": dates,
        "amounts": amounts,
        "inv_words": inv_words,
        "sup_names": sup_names,
        "bank_accounts": BankAccount.objects.filter(account=account)
    }
    return render(request, "inputapp/process_upload.html", context)

@login_required(login_url='/auth/login/')
def submit_upload(request):
    if request.method == "POST":
        post_copy = request.POST.copy()
        form = InputForm(data=request.POST)
        account = Account.objects.get(pk=request.session["account_id"])
        business = Business.objects.get(account=account)
        upload = Upload.objects.get(pk=post_copy.get("upload_id"))
        if form.is_valid():
            try:
                with transaction.atomic():
                    input = Input.objects.filter(account=account, user=request.user, upload=upload)
                    if input:
                        form = InputForm(data=request.POST, instance=input)
                        form.save()
                    else:
                        input = form.save()
                        input.account = account
                        input.user = request.user
                        input.upload = upload
                        input.save()

                        c_data = form.cleaned_data

                        # Create supplier if does not exists
                        if request.session["supplier_name"] is None:
                            supplier = Supplier(account=account, name=c_data.get("supplier_name"))
                            supplier.save()
                            # attached extracted data for backend processing
                            SupplierData.objects.create(supplier=supplier, upload=upload)
                        
                        # create purchase journal and attached extracted input
                        PurchaseJournal.objects.create(
                            business = business,
                            input = input,
                            date = input.transaction_date,
                            ref = input.invoice_number,
                            tax_entry = "Inclusive",
                            description = input.description,
                            amount = input.total_amount,
                            debit = input.category,
                            credit = input.cash_source,
                        )

                        # append gtrial balanace and attached extracted input
                        TrialBalance.objects.create(
                            business = business,
                            input = input,
                            type = "debit",
                            account = "001",
                            description = input.category,
                            debit = input.total_amount,
                        )

                        TrialBalance.objects.create(
                            business = business,
                            input = input,
                            type = "credit",
                            account = "001",
                            description = input.cash_source,
                            credit = input.total_amount,
                        )
                    utils.log_user(request.user, "Submited input")
                    return utils.response(utils.OK_TAG, "/input/")
            except Exception as e:
                transaction.rollback()
                return utils.response(utils.ERROR_TAG, str(e))
        else:
            error = ""
            for msg in form.errors:
                error += "{}.<br/>".format(msg)
            return utils.response(utils.ERROR_TAG, error)
    else:
        return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

@login_required(login_url='/auth/login/')
def scan(request):
    context = {
        "page": "input",
    }
    return render(request, "inputapp/scan.html", context)

@login_required(login_url='/auth/login/')
def email(request):
    context = {
        "page": "input",
    }
    return render(request, "inputapp/email.html", context)

