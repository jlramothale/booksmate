import json

''' Pre-Populate Engine '''

'''
    Document type will be extracted from the words space
'''
class DocumentType:
    
    def __init__(self, search_space):
        self.key_space = [
            "INVOICE",
            "TAX INVOICE",
            "RECEIPT"
        ]
        self.search_space = search_space

    def __str__(self):
        return "Document Type"

    def get_document_type(self):
        for key, word in self.search_space.items():
            for space in self.key_space:
                if space == word.upper():
                    return space
        return None


'''
    Invoice number comes from the form. If the invoice number cannot be found from the form, 
    load all lines words seach space on the drop down
'''
class InvoiceNumber:
    
    def __init__(self, search_space):
        self.key_space = [
            "INVOICE",
            "INVOICE NO",
            "REFERENCE",
            "OUR REFERENCE", 
            "INVOICE REFERENCE"
            "INVOICE NR",
            "NUMBER", 
        ]
        self.search_space = search_space

    def __str__(self):
        return "Invoice Number"

    def get_invoice_number(self):
        for key, value in self.search_space.items():
            for space in self.key_space:
                key = Helper.key_replace(key)
                if space in key.upper():
                    return value
        return None

    def get_only_words(self, form, in_words):
        words = []
        for key, value in form.items():
            if Helper.is_date(value):
                continue
            if Helper.is_digit(value):
                continue
            words.append(value)
        for key, value in in_words.items():
            if Helper.is_date(value):
                continue
            if Helper.is_digit(value):
                continue
            if value in words:
                continue
            words.append(value)
        return words
 
'''
    Transaction date comes from the form. If the transaction date cannot be found from the form, 
    load all lines words seach space on the drop down
'''
class TransactionDate:

    def __init__(self, search_space):
        self.key_space = [
            "DATE",
            "INVOICE DATE",
            "DATE CREATED",
            "PRINT DATE",
        ]
        self.search_space = search_space

    def __str__(self):
        return "Transaction Date"

    def get_transaction_date(self):
        for key, value in self.search_space.items():
            for space in self.key_space:
                key = Helper.key_replace(key)
                if space in key.upper():
                    return value
        return None

    def get_only_dates(self, words):
        dates = []
        for key, value in words.items():
            if Helper.is_digit(value):
                continue
            if Helper.is_date(value):
                dates.append(value)
        return dates

'''
   TotalAmount comes from the form. If the total amount cannot be found from the form, 
    load all lines words seach space on the drop down
'''

import locale
class TotalAmount:
    
    def __init__(self, search_space):
        self.key_space = [
            "TOTAL",
            "TOTAL (INCL)",
            "TOTAL R",
            "TOTAL INC",
        ]
        self.sub_key_space = [
            "SUBTOTAL",
            "SUB-TOTAL",
        ]
        self.search_space = search_space

    def __str__(self):
        return "Total Amount"

    def get_total_amount(self):
        for key, value in self.search_space.items():
            for space in self.key_space:
                key = Helper.key_replace(key)
                if space == key.upper():
                    value = value.replace(" ", "")
                    try:
                        # print(key, value)
                        locale.setlocale(locale.LC_ALL, 'en_US.UTF-8')
                        value = locale.atof(value)
                        return value
                    except ValueError:
                        print(key, value)
        return None
    
    def get_sub_total(self):
        for key, value in self.search_space.items():
            for space in self.sub_key_space:
                key = Helper.key_replace(key)
                if space in key.upper():
                    return value
        return None

    def get_only_amounts(self, words, form):
        amounts = []
        for key, value in words.items():
            if Helper.is_date(value):
                continue
            if Helper.is_digit(value):
                amounts.append(value)
        for key, value in form.items():
            if Helper.is_digit(value):
                if value not in amounts:
                    amounts.append(value)
        return amounts

class SupplierName:

    def __init__(self, search_space):
        self.search_space = search_space

    def __str__(self):
        return "SupplierName"

    def get_supplier_name(self, suppliers):
        for key, value in self.search_space.items():
            for supplier in suppliers:
                if supplier.name == value:
                    return supplier.name
        return None

    def get_poosible_sup_names(self, lines):
        names = []
        for key, value in lines.items():
            if Helper.is_digit(value):
                continue
            if Helper.is_date(value):
                continue
            names.append(value)
        return names

class CleanInputs:
    def __init__(self):
        pass

    def clean_words(words, type="digit"):
        tmp_words = []
        if type == "digit":
            for key, value in words.items():
                if Helper.is_digit(value):
                    tmp_words.append(value)
        else:
            for key, value in words.items():
                if not Helper.is_digit(value):
                    tmp_words.append(value)
        return tmp_words

    def clean_form(form, type="digit"):
        tmp_form = {}
        if type == "digit":
            for key, value in form.items():
                if Helper.is_digit(value):
                    tmp_form.update({key:value})
        else:
            for key, value in form.items():
                if not Helper.is_digit(value):
                    tmp_form.update({key:value})
            
        return tmp_form

    def clean_lines(lines, type="digit"):
        tmp_lines = {}
        if type == "digit":
            for key, value in lines.items():
                if Helper.is_digit(value):
                    tmp_lines.update({key:value})
        else:
            for key, value in lines.items():
                if not Helper.is_digit(value):
                    tmp_lines.update({key:value})
            
        return tmp_lines
        

from dateutil.parser import parse
class Helper:

    def key_replace(key):
        key = key.replace(":", "")
        key = key.replace(":.", "")
        return key

    def is_digit(value):
        try:
            locale.setlocale(locale.LC_ALL, 'en_US.UTF-8')
            value = locale.atof(value)
            return True
        except ValueError:
            return False

    def is_date(value):
        try: 
            parse(value, fuzzy=False)
            return True
        except Exception as e:
            return False

