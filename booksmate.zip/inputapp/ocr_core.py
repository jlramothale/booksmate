
import io
import sys
import math
import boto3
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont
from pdf2image import convert_from_path 

def get_binary_image(document):
    with open(document, "rb") as image:
        byte_image = image.read()
    stream = io.BytesIO(byte_image)
    binary_image = stream.getvalue()
    return binary_image

def analyze_all(binary_image):
    client = boto3.client('textract')
    response = client.analyze_document(
        Document={'Bytes': binary_image},
        FeatureTypes=["FORMS", "TABLES"]
    )
    return response

def analyze_text(binary_image):
    client = boto3.client('textract')
    response = client.detect_document_text(
        Document={'Bytes': binary_image},
    )
    return response

def analyze_form(binary_image):
    client = boto3.client('textract')
    response = client.analyze_document(
        Document={'Bytes': binary_image},
        FeatureTypes=["FORMS"]
    )
    return response

def analyze_table(binary_image):
    client = boto3.client('textract')
    response = client.analyze_document(
        Document={'Bytes': binary_image},
        FeatureTypes=["TABLES"]
    )
    return response

def comprehend_text(text):
    comprehend = boto3.client('comprehend')
    sentiment =  comprehend.detect_sentiment(LanguageCode="en", Text=text)
    print ("\nSentiment\n========\n{}".format(sentiment.get('Sentiment')))
    entities =  comprehend.detect_entities(LanguageCode="en", Text=text)
    print("\nEntities\n========")
    for entity in entities["Entities"]:
        print ("{}\t=>\t{}".format(entity["Type"], entity["Text"]))

def pdf_to_image(document):
    pages = convert_from_path(document.path, 500)
    image_counter = 1
    for page in pages: 
        filename = "page_" + str(image_counter) + ".jpg"
        page.save("images/" + filename, 'JPEG')
        image_counter = image_counter + 1