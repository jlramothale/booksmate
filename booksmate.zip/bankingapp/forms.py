from django import forms
from businessapp.models import (
    Business, BankAccount, PettyCashAccount, DirectorAccount
)

class BankAccountForm(forms.ModelForm):
    account_holder = forms.CharField(max_length=256, required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    account_number = forms.CharField(max_length=256, required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    account_type = forms.CharField(max_length=256, required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    branch_name = forms.CharField(max_length=256, required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    branch_code = forms.CharField(max_length=256, required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    linked = forms.CharField(max_length=256, required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    curren_balance = forms.CharField(max_length=256, required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    available_balance = forms.CharField(max_length=256, required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))

    class Meta:
        model = BankAccount
        fields = [
            "account_holder", "account_number",
            "account_type", "branch_name", "branch_code",
            "linked", "curren_balance", "available_balance"
        ]

class PettyCashForm(forms.ModelForm):
    name = forms.CharField(max_length=256, required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    description = forms.CharField(max_length=256, required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))

    class Meta:
        model = PettyCashAccount
        fields = [
            "name", "description",
        ]


class DirectorAccountForm(forms.ModelForm):
    name = forms.CharField(max_length=256, required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))
    director_name = forms.CharField(max_length=256, required=False, widget=forms.TextInput(attrs={'class':'form-control', "data-rule":"required"}))

    class Meta:
        model = DirectorAccount
        fields = [
            "name", "director_name",
        ]

