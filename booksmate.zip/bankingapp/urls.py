from django.urls import path
from . import views

app_name = "bankingapp"

urlpatterns = [
    path('', views.banking, name="banking"),
    path('bank-accounts/', views.bank_accounts, name="bank-accounts"),
    path('view-bank-account/<str:hash>/<int:id>/', views.view_bank_account, name="view-bank-account"),
    path('save-bank-account/', views.save_bank_account, name="save-bank-account"),

    path('petty-cash-accounts/', views.petty_cash_accounts, name="petty-cash-accounts"),
    path('view-petty-cash-account/<str:hash>/<int:id>/', views.view_petty_cash_account, name="view-petty-cash-account"),
    path('save-petty-cash-account/', views.save_petty_cash_account, name="save-petty-cash-account"),

    path('director-loan-accounts/', views.director_loan_account, name="director-loan-accounts"),
    path('view-director-loan-account/<str:hash>/<int:id>/', views.view_director_loan_account, name="view-director-loan-account"),
    path('save-director-loan-account/', views.save_director_loan_account, name="save-director-loan-account"),

    path('upload-statement/', views.upload_statement, name="upload-statement"),
    path('bank-rules/', views.bank_rules, name="bank-rules"),

    path('get-accounts/', views.get_accounts, name="get-accounts")
]
