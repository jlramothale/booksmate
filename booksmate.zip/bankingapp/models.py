from django.db import models
from django.utils import timezone
from usersapp.models import Account, User
from businessapp.models import BankAccount

# CobrandLogin: maintains cobrand session logins, for each user
class CobrandLogin(models.Model):
    cob_id = models.CharField(max_length=256, default='', blank=True, null=True)
    application_id = models.CharField(max_length=256, default='', blank=True, null=True)
    locale = models.CharField(max_length=256, default='', blank=True, null=True)
    session = models.CharField(max_length=512, default='', blank=True, null=True)
    date_added = models.DateTimeField(default=timezone.now, blank=True, null=True)
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name_plural = "CobrandLogin"
    
    def __str__(self):
        return self.cobrand.login_name

# A yodlee user is the Admin Account. i.e, a single yodlee user for each single account. 1-To-1
class YodleeUser(models.Model):
    account = models.OneToOneField(Account, blank=True, null=True, on_delete=models.SET_NULL)
    login_name = models.CharField(max_length=256, default='', blank=True, null=True)
    password = models.CharField(max_length=256, default='', blank=True, null=True)
    role_type = models.CharField(max_length=128, default='', blank=True, null=True)
    date_added = models.DateTimeField(default=timezone.now, blank=True, null=True)
    date_deleted = models.DateTimeField(default=timezone.now, blank=True, null=True)
    deleted = models.BooleanField(default=False)
    
    class Meta:
        verbose_name_plural = "YodleeUsers"
    
    def __str__(self):
        return self.login_name
