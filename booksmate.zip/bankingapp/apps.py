from django.apps import AppConfig


class BankingappConfig(AppConfig):
    name = 'bankingapp'
