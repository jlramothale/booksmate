import requests, json

cobrand_name = "sbCobd5ed55a2e1415c61ec43554d378b29476a"
cobrand_password = "6dabb823-df1f-4fbb-ba7c-c7269ae5e7ec"
fast_link = "https://node.developer.yodlee.com/authenticate/restserver/"
yodlee_api = "https://developer.api.yodlee.com/ysl/"
user_name = "sbMemd5ed55a2e1415c61ec43554d378b29476a5"
user_password = "sbMemd5ed55a2e1415c61ec43554d378b29476a5#123"

# locale = "en_ZA"
locale = "en_US"

def conbrand_login():
    login_url = "{}cobrand/login".format(yodlee_api)
    headers = {
        'Api-Version': '1.1',
        'Content-Type': 'application/json',
        "Cobrand-Name" : "restserver",
    }
    data = {
        "cobrand": {
            "cobrandLogin": cobrand_name,
            "cobrandPassword": cobrand_password, 
            "locale": locale,
        }
    }
    return requests.post(login_url, data=json.dumps(data), headers=headers)

def user_login(cobSession):
    login_url = "{}user/login".format(yodlee_api)
    headers = {
        'Api-Version': '1.1',
        "Authorization": "cobSession=" + cobSession,
        'Content-Type': 'application/json',
        "Cobrand-Name" : "restserver",
    }
    data = {
        "user": {
            "loginName": user_name,
            "password": user_password, 
            "locale": locale,
        }
    }
    return requests.post(login_url, data=json.dumps(data), headers=headers)

def get_fast_link_tokens(cobSession, userSession):
    tokens_url = "{}user/accessTokens?appIds=10003600".format(yodlee_api)
    headers = {
        'Api-Version': '1.1',
        "Authorization": "cobSession={},userSession={}".format(cobSession, userSession),
        'Content-Type': 'application/json',
        "Cobrand-Name" : "restserver",
    }
    return requests.get(tokens_url, headers=headers)

def get_accounts(cobSession, userSession):
    url = "{}accounts".format(yodlee_api)
    headers = {
        'Api-Version': '1.1',
        "Authorization": "cobSession={},userSession={}".format(cobSession, userSession),
        'Content-Type': 'application/json',
        "Cobrand-Name" : "restserver",
    }
    return requests.get(url, headers=headers)

def get_transactions_count(cobSession, userSession):
    url = "{}transactions/count".format(yodlee_api)
    headers = {
        'Api-Version': '1.1',
        "Authorization": "cobSession={},userSession={}".format(cobSession, userSession),
        'Content-Type': 'application/json',
        "Cobrand-Name" : "restserver",
    }
    return requests.get(url, headers=headers)

def get_transactions(cobSession, userSession):
    url = "{}transactions".format(yodlee_api)
    headers = {
        'Api-Version': '1.1',
        "Authorization": "cobSession={},userSession={}".format(cobSession, userSession),
        'Content-Type': 'application/json',
        "Cobrand-Name" : "restserver",
    }
    return requests.get(url, headers=headers)
