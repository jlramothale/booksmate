from django.shortcuts import render, redirect, get_object_or_404
from django.db import transaction
from django.utils import timezone
from booksmate import utils, settings
import requests, json
from . import yodlee
from django.contrib.auth.decorators import login_required
from usersapp.models import Account, User
from businessapp.models import (
    Business, BankAccount, PettyCashAccount, DirectorAccount
)
from systemapp.models import (
    Bank
)
from .forms import (
    BankAccountForm, PettyCashForm, DirectorAccountForm
)

@login_required(login_url='/auth/login/')
def banking(request):
    context = {
        "page": "banking",
    }
    return render(request, "bankingapp/banking.html", context)

@login_required(login_url='/auth/login/')
def bank_accounts(request):
    account = Account.objects.get(pk=request.session["account_id"])
    if request.method == "POST":
        form_data = request.POST.copy()
        bank_form = BankAccountForm(request.POST)
        if bank_form.is_valid():
            try:
                with transaction.atomic():
                    business = Business.objects.get(pk=request.session["business_id"])
                    bank = bank_form.save()
                    bank.bank_name = form_data.get("bank_name")
                    bank.account = account
                    bank.business = business
                    bank.save()
                    utils.log_user(request.user, f"Added business bank account")
                    return utils.response(utils.OK_TAG, utils.OK_MSG)
            except Exception as e:
                transaction.rollback()
                return utils.response(utils.ERROR_TAG, str(e))
        else:
            error = ""
            for msg in bank_form.errors:
                error += "{}.<br/>".format(msg)
            return utils.response(utils.ERROR_TAG, error)
    else:
        context = {
            "page": "banking", "hash": utils.get_hash(request),
            "banks": Bank.objects.all(),
            "accounts" : BankAccount.objects.filter(account=account),
            "bank_form": BankAccountForm()
        }
        return render(request, "bankingapp/bank_accounts.html", context)

@login_required(login_url='/auth/login/')
def view_bank_account(request, hash, id):
    bank = BankAccount.objects.get(pk=id)
    bank_form = BankAccountForm(instance=bank)
    context = {
        "page": "banking", "hash": utils.get_hash(request),
        "bank": bank,
        "bank_form": bank_form
    }
    # accounts = []
    # for account in request.session["ydl_accounts"]:
    #     if account["CONTAINER"] == "bank":
    #         acc = {
    #             "accountName" : account["accountName"],
    #             "accountType" : account["accountType"],
    #             "accountNumber": account["accountNumber"],
    #             "container": account["CONTAINER"],
    #             "balance" : account["balance"]["amount"],
    #             "currentBalance" : account["currentBalance"]["amount"],
    #             "availableBalance" : account["availableBalance"]["amount"],
    #         }
    #         accounts.append(acc)
    # print(accounts)
    return render(request, "bankingapp/view_bank_account.html", context)

@login_required(login_url='/auth/login/')
def save_bank_account(request):
    if request.method == "POST":
        form_data = request.POST.copy()
        bank = BankAccount.objects.get(pk=form_data.get("id"))
        bank_form = BankAccountForm(data=request.POST, instance=bank)
        if bank_form.is_valid():
            try:
                with transaction.atomic():
                    bank = bank_form.save()
                    bank.save()
                    utils.log_user(request.user, f"Updated business bank account")
                    return utils.response(utils.OK_TAG, utils.OK_MSG)
            except Exception as e:
                transaction.rollback()
                return utils.response(utils.ERROR_TAG, str(e))
        else:
            error = ""
            for msg in bank_form.errors:
                error += "{}.<br/>".format(msg)
            return utils.response(utils.ERROR_TAG, error)
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

@login_required(login_url='/auth/login/')
def petty_cash_accounts(request):
    account = Account.objects.get(pk=request.session["account_id"])
    if request.method == "POST":
        account_form = PettyCashForm(request.POST)
        if account_form.is_valid():
            try:
                with transaction.atomic():
                    business = Business.objects.get(pk=request.session["business_id"])
                    petty_cash = account_form.save()
                    petty_cash.account = account
                    petty_cash.business = business
                    petty_cash.save()
                    utils.log_user(request.user, f"Added petty cash account")
                    return utils.response(utils.OK_TAG, utils.OK_MSG)
            except Exception as e:
                transaction.rollback()
                return utils.response(utils.ERROR_TAG, str(e))
        else:
            error = ""
            for msg in account_form.errors:
                error += "{}.<br/>".format(msg)
            return utils.response(utils.ERROR_TAG, error)
    else:
        context = {
            "page": "banking",
            "accounts" : PettyCashAccount.objects.filter(account=account),
            "account_form": PettyCashForm()
        }
        return render(request, "bankingapp/petty_cash_accounts.html", context)

@login_required(login_url='/auth/login/')
def view_petty_cash_account(request, hash, id):
    pass

@login_required(login_url='/auth/login/')
def save_petty_cash_account(request):
    pass

@login_required(login_url='/auth/login/')
def director_loan_account(request):
    account = Account.objects.get(pk=request.session["account_id"])
    if request.method == "POST":
        account_form = DirectorAccountForm(request.POST)
        if account_form.is_valid():
            try:
                with transaction.atomic():
                    business = Business.objects.get(pk=request.session["business_id"])
                    director_account = account_form.save()
                    director_account.account = account
                    director_account.business = business
                    director_account.save()
                    utils.log_user(request.user, f"Added directors account")
                    return utils.response(utils.OK_TAG, utils.OK_MSG)
            except Exception as e:
                transaction.rollback()
                return utils.response(utils.ERROR_TAG, str(e))
        else:
            error = ""
            for msg in account_form.errors:
                error += "{}.<br/>".format(msg)
            return utils.response(utils.ERROR_TAG, error)
    else:
        context = {
            "page": "banking",
            "accounts" : DirectorAccount.objects.filter(account=account),
            "account_form": DirectorAccountForm()
        }
        return render(request, "bankingapp/director_loan_account.html", context)

@login_required(login_url='/auth/login/')
def view_director_loan_account(request, hash, id):
    pass

@login_required(login_url='/auth/login/')
def save_director_loan_account(request):
    pass

@login_required(login_url='/auth/login/')
def link_yodlee(request):
    # result = yodlee.conbrand_login().json()
    # request.session["ydl_cob_login"] = {
    #     "cobrandId": result["cobrandId"],
    #     "applicationId": result["applicationId"],
    #     "cobSession": result["session"]["cobSession"]
    # }
    # result = yodlee.user_login(request.session["ydl_cob_login"]["cobSession"]).json()
    # request.session["ydl_user_login"] = {
    #     "loginName": result["user"]["loginName"],
    #     "userId": result["user"]["id"],
    #     "userSession": result["user"]["session"]["userSession"]
    # }
    # result = yodlee.get_fast_link_tokens(
    #     request.session["ydl_cob_login"]["cobSession"], 
    #     request.session["ydl_user_login"]["userSession"]
    # ).json()
    # request.session["ydl_fastlink_tokens"] = result["user"]["accessTokens"][0]
    # print(request.session["ydl_cob_login"])
    # print(request.session["ydl_user_login"])
    # print(request.session["ydl_fastlink_tokens"])
    # result = yodlee.get_accounts(
    #     request.session["ydl_cob_login"]["cobSession"], 
    #     request.session["ydl_user_login"]["userSession"]
    # ).json()
    # request.session["ydl_accounts"] = result["account"]
    accounts = []
    for account in request.session["ydl_accounts"]:
        if account["CONTAINER"] == "bank":
            acc = {
                "accountName" : account["accountName"],
                "accountType" : account["accountType"],
                "accountNumber": account["accountNumber"],
                "container": account["CONTAINER"],
                "balance" : account["balance"]["amount"],
                "currentBalance" : account["currentBalance"]["amount"],
                "availableBalance" : account["availableBalance"]["amount"],
            }
            accounts.append(acc)
    # print(accounts)
    # result = yodlee.get_transactions_count(
    #     request.session["ydl_cob_login"]["cobSession"], 
    #     request.session["ydl_user_login"]["userSession"]
    # ).json()
    # print(result)
    # result = yodlee.get_transactions(
    #     request.session["ydl_cob_login"]["cobSession"], 
    #     request.session["ydl_user_login"]["userSession"]
    # ).json()
    # print(result)

    context = {
        "page": "banking", "accounts": accounts,
    }
    return render(request, "bankingapp/link_yodlee.html", context)

@login_required(login_url='/auth/login/')
def upload_statement(request):
    context = {
        "page": "banking",
    }
    return render(request, "bankingapp/upload_statement.html", context)

@login_required(login_url='/auth/login/')
def bank_rules(request):
    context = {
        "page": "banking",
    }
    return render(request, "bankingapp/bank_rules.html", context)

@login_required(login_url='/auth/login/')
def get_accounts(request):
    if request.method == "POST":
        response = []
        form_data = request.POST.copy()
        account = Account.objects.get(pk=request.session["account_id"])
        if form_data.get("type") == "bank":
            accounts = BankAccount.objects.filter(account=account)
            for account in accounts:
                response.append("{} ACC No: {}".format(account.bank_name, account.account_number))
            return utils.response(utils.OK_TAG, response)

        if form_data.get("type") == "cash":
            accounts = PettyCashAccount.objects.filter(account=account)
            for account in accounts:
                response.append("Petty Cash: {}".format(account.name))
            return utils.response(utils.OK_TAG, response)

        if form_data.get("type") == "director":
            accounts = DirectorAccount.objects.filter(account=account)
            for account in accounts:
                response.append("Director Loan: {}".format(account.name))
            return utils.response(utils.OK_TAG, response)
    return utils.response(utils.ERROR_TAG, utils.ERROR_MSG)
        