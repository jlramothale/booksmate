from django.apps import AppConfig


class ReportsappConfig(AppConfig):
    name = 'reportsapp'
