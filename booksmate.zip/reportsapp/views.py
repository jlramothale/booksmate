from django.shortcuts import render, redirect, get_object_or_404
from django.db import transaction
from django.utils import timezone
from booksmate import utils, settings
from django.contrib.auth.decorators import login_required

# Create your views here.
@login_required(login_url='/auth/login/')
def reports(request):
    context = {
        "page": "financial-reports",
    }
    return render(request, "reportsapp/reports.html", context)

@login_required(login_url='/auth/login/')
def annual_financial_reports(request):
    context = {
        "page": "financial-reports",
    }
    return render(request, "reportsapp/annual_financial_reports.html", context)

@login_required(login_url='/auth/login/')
def past_month_accounts(request):
    context = {
        "page": "financial-reports",
    }
    return render(request, "reportsapp/past_month_accounts.html", context)

@login_required(login_url='/auth/login/')
def report_to_date(request):
    context = {
        "page": "financial-reports",
    }
    return render(request, "reportsapp/report_to_date.html", context)

@login_required(login_url='/auth/login/')
def tax_compliance_report(request):
    context = {
        "page": "financial-reports",
    }
    return render(request, "reportsapp/tax_compliance_report.html", context)

@login_required(login_url='/auth/login/')
def customer_reports(request):
    context = {
        "page": "financial-reports",
    }
    return render(request, "reportsapp/customer_reports.html", context)

@login_required(login_url='/auth/login/')
def suppliers_report(request):
    context = {
        "page": "financial-reports",
    }
    return render(request, "reportsapp/suppliers_report.html", context)

@login_required(login_url='/auth/login/')
def employees_reports(request):
    context = {
        "page": "financial-reports",
    }
    return render(request, "reportsapp/employees_reports.html", context)

@login_required(login_url='/auth/login/')
def assets_register(request):
    context = {
        "page": "financial-reports",
    }
    return render(request, "reportsapp/assets_register.html", context)

@login_required(login_url='/auth/login/')
def contact_details(request):
    context = {
        "page": "financial-reports",
    }
    return render(request, "reportsapp/contact_details.html", context)
