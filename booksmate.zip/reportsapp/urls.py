from django.urls import path
from . import views

app_name = "reportsapp"

urlpatterns = [
    path('', views.reports, name="reports"),
]
