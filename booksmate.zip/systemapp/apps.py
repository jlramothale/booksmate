from django.apps import AppConfig


class SystemappConfig(AppConfig):
    name = 'systemapp'
