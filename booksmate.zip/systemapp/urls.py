from django.urls import path
from . import views

app_name = "systemapp"

urlpatterns = [
    # path('', views.home, name="home"),
    # path('issues/', views.issues, name="issues"),
    # path('tech-stack/', views.tech_stack, name="tech-stack"),
    # path('mock-data/', views.mock_data, name="mock-data"),

    # path('load-business-data/', views.load_business_data, name="load-business-data/"),
]
