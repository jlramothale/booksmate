from django.db import models
from django.utils import timezone
 
class Country(models.Model):
    name = models.CharField(max_length=128, unique=True, default='', null=True) # South Africa
    abbreviation = models.CharField(max_length=64, default='', blank=True, null=True) # RSA
    zip_code = models.CharField(max_length=64, default='', blank=True, null=True) # ZA
    deleted = models.BooleanField(default=False, blank=True, null=True)

    class Meta:
        verbose_name = "Country"
        verbose_name_plural = "Countries"

    def __str__(self):
        return self.name

class DialingCode(models.Model):
    country = models.ForeignKey(Country, blank=True, null=True, on_delete=models.SET_NULL)
    name = models.CharField(max_length=128, default='', blank=True, null=True) # +27
    code = models.CharField(max_length=16, default='', blank=True, null=True) # +27
    deleted = models.BooleanField(default=False, blank=True, null=True)

    class Meta:
        verbose_name = "DialingCode"
        verbose_name_plural = "DialingCodes"

    def __str__(self):
        return self.name

class Currency(models.Model):
    country = models.ForeignKey(Country, blank=True, null=True, on_delete=models.SET_NULL)
    name = models.CharField(max_length=64, default='', blank=True, null=True) # Rand
    code = models.CharField(max_length=32, default='', blank=True, null=True) # ZAR
    symbol = models.CharField(max_length=8, default='', blank=True, null=True) # R
    deleted = models.BooleanField(default=False, blank=True, null=True)

    class Meta:
        verbose_name = "Currency"
        verbose_name_plural = "Currencies"

    def __str__(self):
        return self.name

class TaxRate(models.Model):
    country = models.ForeignKey(Country, blank=True, null=True, on_delete=models.SET_NULL)
    name = models.CharField(max_length=128, default='', blank=True, null=True) # VAT
    rate = models.CharField(max_length=64, default='', blank=True, null=True) # 15
    description = models.CharField(max_length=256, default='', blank=True, null=True) # Standard Tax
    deleted = models.BooleanField(default=False, blank=True, null=True)

    class Meta:
        verbose_name = "TaxRate"
        verbose_name_plural = "TaxRates"

    def __str__(self):
        return self.name

class Bank(models.Model):
    country = models.ForeignKey(Country, blank=True, null=True, on_delete=models.SET_NULL) # SA
    name = models.CharField(max_length=128, default='', blank=True, null=True) # First National Bank
    code = models.CharField(max_length=16, default='', blank=True, null=True) # FNB
    description = models.CharField(max_length=1024, default='', blank=True, null=True)
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name = "Bank"
        verbose_name_plural = "Banks"

    def __str__(self):
        return self.name

class PaymentMethod(models.Model):
    name = models.CharField(max_length=256, default='', blank=True, null=True) # EFT
    description = models.CharField(max_length=1024, default='', blank=True, null=True) # Electronic Transfer 
    instructions = models.TextField(default='', blank=True, null=True)

    class Meta:
        verbose_name_plural = "PaymentMethods"

class BillingPackage(models.Model):
    name = models.CharField(max_length=256, default='', blank=True, null=True) # Starter
    price = models.CharField(max_length=256, default='', blank=True, null=True) # R300
    description = models.TextField(default='', blank=True, null=True) # Description
    per_month = models.CharField(max_length=128, default='', blank=True, null=True) # R300
    per_year = models.CharField(max_length=128, default='', blank=True, null=True) # R300 x 12 = R3600
    deleted = models.BooleanField(default=False) 

    class Meta:
        verbose_name_plural = "BillingPackages"

class Sector(models.Model):
    name = models.CharField(max_length=128, unique=True, default='', blank=True)
    description = models.CharField(max_length=1024, default='', blank=True)
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name = "Sector"
        verbose_name_plural = "Sectors"

    def __str__(self):
        return self.name

class Industry(models.Model):
    name = models.CharField(max_length=128, unique=True, default='', blank=True)
    description = models.CharField(max_length=1024, default='', blank=True)
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name = "Industry"
        verbose_name_plural = "Industries"

    def __str__(self):
        return self.name
 
class BusinessType(models.Model):
    country = models.ForeignKey(Country, blank=True, null=True, on_delete=models.SET_NULL)
    name = models.CharField(max_length=128, default='', blank=True)
    abbreviation = models.CharField(max_length=64, default='', blank=True)
    description = models.CharField(max_length=1024, default='', blank=True)
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name = "BusinessType"
        verbose_name_plural = "BusinessTypes"

    def __str__(self):
        return self.name

class StatutoryInstitution(models.Model):
    country = models.ForeignKey(Country, blank=True, null=True, on_delete=models.SET_NULL) # SA
    name = models.CharField(max_length=128, default='', blank=True) # South African Revenue Services
    abbreviation = models.CharField(max_length=64, default='', blank=True) # SARS
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name = "StatutoryInstitution"
        verbose_name_plural = "StatutoryInstitutions"

    def __str__(self):
        return self.name

class StatutoryRegistration(models.Model):
    country = models.ForeignKey(Country, blank=True, null=True, on_delete=models.SET_NULL) # SA
    name = models.CharField(max_length=128, default='', blank=True) # Income Tax / Value Added Tax
    abbreviation = models.CharField(max_length=64, default='', blank=True) # Tax / VAT
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name = "StatutoryRegistration"
        verbose_name_plural = "StatutoryRegistrations"

    def __str__(self):
        return self.name

class COACategory(models.Model):
    name = models.CharField(max_length=128, default='', blank=True, null=True) # Assets
    description = models.CharField(max_length=1024, default='', blank=True, null=True)
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name = "COACategory"
        verbose_name_plural = "COACategories"

    def __str__(self):
        return self.name

class COAISAccounts(models.Model):
    coa_category = models.ForeignKey(COACategory, blank=True, null=True, on_delete=models.SET_NULL) # Assets
    account = models.CharField(max_length=128, default='', blank=True, null=True)
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name = "COAISAccounts"
        verbose_name_plural = "COAISAccounts"

    def __str__(self):
        return self.name

class IncomeStatementCOA(models.Model):
    business_type = models.ForeignKey(BusinessType, blank=True, null=True, on_delete=models.SET_NULL) # PTY
    coa_category = models.ForeignKey(COACategory, blank=True, null=True, on_delete=models.SET_NULL) # Assets
    account_number = models.CharField(max_length=128, default='', blank=True, null=True) # 11
    account = models.CharField(max_length=512, default='', blank=True, null=True) # Fixed Assets
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name = "IncomeStatementCOA"
        verbose_name_plural = "IncomeStatementCOA"

    def __str__(self):
        return self.account

class COAType(models.Model):
    name = models.CharField(max_length=128, default='', blank=True, null=True) # Non-Current Assets
    description = models.CharField(max_length=1024, default='', blank=True, null=True)
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name = "COAType"
        verbose_name_plural = "COATypes"

    def __str__(self):
        return self.name

class BalanceSheetCOA(models.Model):
    business_type = models.ForeignKey(BusinessType, blank=True, null=True, on_delete=models.SET_NULL) # PTY
    coa_category = models.ForeignKey(COACategory, blank=True, null=True, on_delete=models.SET_NULL) # Assets
    coa_type = models.ForeignKey(COAType, blank=True, null=True, on_delete=models.SET_NULL) # Non-Current Assets
    account_number = models.CharField(max_length=128, default='', blank=True, null=True) # 11
    account = models.CharField(max_length=512, default='', blank=True, null=True) # Fixed Assets
    deleted = models.BooleanField(default=False)

    class Meta:
        verbose_name = "BalanceSheetCOA"
        verbose_name_plural = "BalanceSheetCOA"

    def __str__(self):
        return self.account
