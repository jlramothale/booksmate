from django.shortcuts import render, redirect, get_object_or_404
from django.db import transaction
from django.utils import timezone
from booksmate import utils, settings
from django.contrib.auth.decorators import login_required
from usersapp.models import Account, User
from systemapp.models import (
    Currency, BillingPackage, Country, Bank, Industry, Sector, BusinessType,
    StatutoryInstitution, StatutoryRegistration, TaxRate
)
from businessapp.models import (
    Business, Registrations, Supplier, Product, Service
)
from businessapp.forms import (
    BuisnessForm, BusilessLogoForm, RegistrationsForm, SupplierForm,
    ProductForm, ServiceForm
)
from createnewapp.models import (
    Customer, PhysicalAddress
)
from createnewapp.forms import (
    CustomerForm, PhysicalAddressForm
)

@login_required(login_url='/auth/login/')
def settings(request):
    context = {
        "page": "settings",
    }
    return render(request, "settingsapp/settings.html", context)

@login_required(login_url='/auth/login/')
def companies(request):
    account = Account.objects.get(pk=request.session["account_id"])
    businesses = Business.objects.filter(account=account)
    context = {
        "page": "settings",
        "subpage": "settingsCompany",
        "hash": utils.get_hash(request),
        "businesses": businesses,
    }
    return render(request, "settingsapp/companies.html", context)

@login_required(login_url='/auth/login/')
def view_company(request, hash, id):
    business = Business.objects.get(pk=id)
    context = {
        "page": "settings",
        "subpage": "settingsCompany",
        "business": business,
        "registrations": Registrations.objects.filter(business=business),
        "currencies" : Currency.objects.all(),
        "industries": Industry.objects.all(),
        "reg_types": BusinessType.objects.all(),
        "s_institutions": StatutoryInstitution.objects.filter(country=1),
        "s_registrations": StatutoryRegistration.objects.filter(country=1),
        "business_form": BuisnessForm(instance=business),
        "logo_form": BusilessLogoForm(),
        "registrations_form": RegistrationsForm()
    }
    return render(request, "settingsapp/view_company.html", context)

@login_required(login_url='/auth/login/')
def save_company(request):
    if request.method == "POST":
        form_data = request.POST.copy()
        business = Business.objects.get(pk=form_data.get("id"))
        business_form = BuisnessForm(request.POST, instance=business)
        if business_form.is_valid():
            try:
                with transaction.atomic():
                    business = business_form.save()
                    business.reg_type = form_data.get("reg_type")
                    business.currency = Currency.objects.get(pk=form_data.get("currency"))
                    business.industry = form_data.get("industry")
                    business.save()
                    utils.log_user(request.user, f"Updated business information")
                    return utils.response(utils.OK_TAG, utils.OK_MSG)
            except Exception as e:
                transaction.rollback()
                return utils.response(utils.ERROR_TAG, str(e))
        else:
            error = ""
            for msg in business_form.errors:
                error += "{}.<br/>".format(msg)
            return utils.response(utils.ERROR_TAG, error)
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

@login_required(login_url='/auth/login/')
def add_company(request):
    pass

@login_required(login_url='/auth/login/')
def change_company_logo(request):
    if request.method == "POST":
        form_data = request.POST.copy()
        business = Business.objects.get(pk=form_data.get("id"))
        logo_form = BusilessLogoForm(data=request.POST, instance=business, files=request.FILES)
        if logo_form.is_valid():
            try:
                with transaction.atomic():
                    logo_form.save()
                    utils.log_user(request.user, f"User profile avatar updated")
                    return utils.response(utils.OK_TAG, utils.OK_MSG)
            except Exception as e:
                transaction.rollback()
                return utils.response(utils.ERROR_TAG, str(e))
        else:
            error = ""
            for msg in logo_form.errors:
                error += "{}: {}<br/>".format(msg, logo_form.errors[msg])
            return utils.response(utils.ERROR_TAG, str(e))
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

@login_required(login_url='/auth/login/')
def add_statutory_registration(request):
    if request.method == "POST":
        form_data = request.POST.copy()
        business = Business.objects.get(pk=form_data.get("id"))
        regs_form = RegistrationsForm(data=request.POST)
        if regs_form.is_valid():
            try:
                with transaction.atomic():
                    registration = regs_form.save()
                    registration.business = business
                    registration.save()
                    utils.log_user(request.user, f"Add statutory registration to business")
                    return utils.response(utils.OK_TAG, utils.OK_MSG)
            except Exception as e:
                transaction.rollback()
                return utils.response(utils.ERROR_TAG, str(e))
        else:
            error = ""
            for msg in regs_form.errors:
                error += "{}: {}<br/>".format(msg, regs_form.errors[msg])
            return utils.response(utils.ERROR_TAG, str(e))
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

@login_required(login_url='/auth/login/')
def save_statutory_registration(request):
    if request.method == "POST":
        form_data = request.POST.copy()
        registration = Registrations.objects.get(pk=form_data.get("id"))
        regs_form = RegistrationsForm(data=request.POST, instance=registration)
        if regs_form.is_valid():
            try:
                with transaction.atomic():
                    regs_form.save()
                    utils.log_user(request.user, f"Updated statutory registration")
                    return utils.response(utils.OK_TAG, utils.OK_MSG)
            except Exception as e:
                transaction.rollback()
                return utils.response(utils.ERROR_TAG, str(e))
        else:
            error = ""
            for msg in regs_form.errors:
                error += "{}: {}<br/>".format(msg, regs_form.errors[msg])
            return utils.response(utils.ERROR_TAG, str(e))
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

@login_required(login_url='/auth/login/')
def delete_statutory_registration(request):
    if request.method == "POST":
        form_data = request.POST.copy()
        try:
            with transaction.atomic():
                Registrations.objects.get(pk=form_data.get("id")).delete()
                utils.log_user(request.user, "Deleted statutory registration")
                return utils.response(utils.OK_TAG, utils.OK_MSG)
        except Exception as e:
            transaction.rollback()
            return utils.response(utils.ERROR_TAG, str(e))
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

@login_required(login_url='/auth/login/')
def customers(request):
    account = Account.objects.get(pk=request.session["account_id"])
    context = {
        "page": "settings",
        "subpage": "settingsCustomers",
        "hash": utils.get_hash(request),
        "customers": Customer.objects.filter(account=account, deleted=0),
    }
    return render(request, "settingsapp/customers.html", context)

@login_required(login_url='/auth/login/')
def deleted_customers(request):
    account = Account.objects.get(pk=request.session["account_id"])
    context = {
        "page": "settings",
        "subpage": "settingsCustomers",
        "hash": utils.get_hash(request),
        "customers": Customer.objects.filter(account=account, deleted=1),
    }
    return render(request, "settingsapp/deleted_customers.html", context)

@login_required(login_url='/auth/login/')
def view_customer(request, hash, id):
    customer = Customer.objects.get(pk=id)
    customer_address = PhysicalAddress.objects.get(customer=customer)
    customer_form = CustomerForm(instance=customer)
    physical_address_form = PhysicalAddressForm(instance=customer_address)
    context = {
        "page": "settings",
        "subpage": "settingsCustomers",
        "customer": customer,
        "customer_address": customer_address,
        "customer_form": customer_form,
        "physical_address_form": physical_address_form
    }
    return render(request, "settingsapp/view_customer.html", context)

@login_required(login_url='/auth/login/')
def save_customer(request):
    if request.method == "POST":
        form_data = request.POST.copy()
        customer = Customer.objects.get(pk=form_data.get("cus_id"))
        customer_address = PhysicalAddress.objects.get(pk=form_data.get("cus_add_id"))
        customer_form = CustomerForm(data=request.POST, instance=customer)
        if customer_form.is_valid():
            try:
                with transaction.atomic():
                    customer_form.save()
                    physical_address_form = PhysicalAddressForm(data=request.POST, instance=customer_address)
                    physical_address_form.is_valid()
                    address = physical_address_form.save()
                    address.country = form_data.get("country")
                    address.save()
                    utils.log_user(request.user, f"Save customer information")
                    return utils.response(utils.OK_TAG, utils.OK_MSG)
            except Exception as e:
                transaction.rollback()
                return utils.response(utils.ERROR_TAG, str(e))
        else:
            error = ""
            for msg in customer_form.errors:
                error += "SSSSS{}.<br/>".format(msg)
            return utils.response(utils.ERROR_TAG, error)
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

@login_required(login_url='/auth/login/')
def delete_customer(request):
    if request.method == "POST":
        form_data = request.POST.copy()
        try:
            with transaction.atomic():
                customer = Customer.objects.get(pk=form_data.get("cus_id"))
                customer.deleted = True
                customer.date_deleted = timezone.now()
                customer.save()
                utils.log_user(request.user, f"Deleted customer")
                return utils.response(utils.OK_TAG, utils.OK_MSG)
        except Exception as e:
            transaction.rollback()
            return utils.response(utils.ERROR_TAG, str(e))
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

@login_required(login_url='/auth/login/')
def activate_customer(request):
    if request.method == "POST":
        form_data = request.POST.copy()
        try:
            with transaction.atomic():
                customer = Customer.objects.get(pk=form_data.get("cus_id"))
                customer.deleted = False
                customer.date_added = timezone.now()
                customer.save()
                utils.log_user(request.user, f"Activated customer")
                return utils.response(utils.OK_TAG, utils.OK_MSG)
        except Exception as e:
            transaction.rollback()
            return utils.response(utils.ERROR_TAG, str(e))
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

@login_required(login_url='/auth/login/')
def suppliers(request):
    account = Account.objects.get(pk=request.session["account_id"])
    context = {
        "page": "settings",
        "subpage": "settingsSuppliers",
        "hash": utils.get_hash(request),
        "suppliers": Supplier.objects.filter(account=account, deleted=0)
    }
    return render(request, "settingsapp/suppliers.html", context)

@login_required(login_url='/auth/login/')
def deleted_suppliers(request):
    account = Account.objects.get(pk=request.session["account_id"])
    context = {
        "page": "settings",
        "subpage": "settingsSuppliers",
        "hash": utils.get_hash(request),
        "suppliers": Supplier.objects.filter(account=account, deleted=1)
    }
    return render(request, "settingsapp/deleted_suppliers.html", context)

@login_required(login_url='/auth/login/')
def view_supplier(request, hash, id):
    supplier = Supplier.objects.get(pk=id)
    context = {
        "page": "settings",
        "subpage": "settingsSuppliers",
        "supplier": supplier,
        "hash": utils.get_hash(request),
        "supplier_form": SupplierForm(instance=supplier)
    }
    return render(request, "settingsapp/view_supplier.html", context)

@login_required(login_url='/auth/login/')
def save_supplier(request):
    if request.method == "POST":
        try:
            with transaction.atomic():
                form_data = request.POST.copy()
                supplier = Supplier.objects.get(pk=form_data.get("sup_id"))
                supplier_form = SupplierForm(request.POST, instance=supplier)
                if supplier_form.is_valid():
                    supplier = supplier_form.save()
                    supplier.save()
                    utils.log_user(request.user, f"Updated supplier information")
                    return utils.response(utils.OK_TAG, utils.OK_MSG)
                else:
                    error = ""
                    for msg in supplier_form.errors:
                        error += "{}.<br/>".format(msg)
                    return utils.response(utils.ERROR_TAG, error)
        except Exception as e:
            transaction.rollback()
            return utils.response(utils.ERROR_TAG, str(e))
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

@login_required(login_url='/auth/login/')
def delete_supplier(request):
    if request.method == "POST":
        try:
            with transaction.atomic():
                form_data = request.POST.copy()
                supplier = Supplier.objects.get(pk=form_data.get("sup_id"))
                supplier.deleted = 1
                supplier.save()
                utils.log_user(request.user, "Deleted supplier {}".format(supplier.name))
                return utils.response(utils.OK_TAG, utils.OK_MSG)
        except Exception as e:
            transaction.rollback()
            return utils.response(utils.ERROR_TAG, str(e))
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

@login_required(login_url='/auth/login/')
def activate_supplier(request):
    if request.method == "POST":
        try:
            with transaction.atomic():
                form_data = request.POST.copy()
                supplier = Supplier.objects.get(pk=form_data.get("sup_id"))
                supplier.deleted = 0
                supplier.save()
                utils.log_user(request.user, "Activated supplier {}".format(supplier.name))
                return utils.response(utils.OK_TAG, utils.OK_MSG)
        except Exception as e:
            transaction.rollback()
            return utils.response(utils.ERROR_TAG, str(e))
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)


@login_required(login_url='/auth/login/')
def chart_of_accounts(request):
    context = {
        "page": "settings",
        "subpage": "settingsChartOfAccounts",
    }
    return render(request, "settingsapp/chart_of_accounts.html", context)

@login_required(login_url='/auth/login/')
def products_services(request):
    account = Account.objects.get(pk=request.session["account_id"])
    products = Product.objects.filter(account=account)
    services = Service.objects.filter(account=account)
    context = {
        "page": "settings",
        "subpage": "settingsServiceProduct",
        "products": products,
        "services": services,
        "product_form": ProductForm(),
        "service_form": ServiceForm(),
        "tax_rates": TaxRate.objects.all()
    }
    return render(request, "settingsapp/products_services.html", context)

@login_required(login_url='/auth/login/')
def add_product(request):
    if request.method == "POST":
        try:
            with transaction.atomic():
                account = Account.objects.get(pk=request.session["account_id"])
                form_data = request.POST.copy()
                prd_form = ProductForm(data=request.POST)
                if prd_form.is_valid():
                    product = prd_form.save()
                    product.account = account
                    product.tax = form_data.get("tax")
                    product.save()
                    utils.log_user(request.user, "Added product {}".format(product.name))
                    return utils.response(utils.OK_TAG, utils.OK_MSG)
                else:
                    return utils.response(utils.ERROR_TAG, utils.ERROR_MSG)
        except Exception as e:
            return utils.response(utils.ERROR_TAG, utils.ERROR_MSG)
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

@login_required(login_url='/auth/login/')
def save_product(request):
    if request.method == "POST":
        try:
            with transaction.atomic():
                form_data = request.POST.copy()
                product = Product.objects.get(pk=form_data.get("prd_id"))
                prd_form = ProductForm(data=request.POST, instance=product)
                if prd_form.is_valid():
                    product = prd_form.save()
                    product.tax = form_data.get("tax")
                    product.save()
                    utils.log_user(request.user, "Updated product {}".format(product.name))
                    return utils.response(utils.OK_TAG, utils.OK_MSG)
                else:
                    return utils.response(utils.ERROR_TAG, utils.ERROR_MSG)
        except Exception as e:
            return utils.response(utils.ERROR_TAG, utils.ERROR_MSG)
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

@login_required(login_url='/auth/login/')
def delete_product(request):
    if request.method == "POST":
        try:
            with transaction.atomic():
                form_data = request.POST.copy()
                product = Product.objects.get(pk=form_data.get("prd_id"))
                prd_name = product.name
                product.delete()
                utils.log_user(request.user, "Deleted product {}".format(prd_name))
                return utils.response(utils.OK_TAG, utils.OK_MSG)
        except Exception as e:
            return utils.response(utils.ERROR_TAG, utils.ERROR_MSG)
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

@login_required(login_url='/auth/login/')
def add_service(request):
    if request.method == "POST":
        try:
            with transaction.atomic():
                account = Account.objects.get(pk=request.session["account_id"])
                form_data = request.POST.copy()
                ser_form = ServiceForm(data=request.POST)
                if ser_form.is_valid():
                    service = ser_form.save()
                    service.account = account
                    service.tax = form_data.get("tax")
                    service.save()
                    utils.log_user(request.user, "Added service {}".format(service.name))
                    return utils.response(utils.OK_TAG, utils.OK_MSG)
                else:
                    return utils.response(utils.ERROR_TAG, utils.ERROR_MSG)
        except Exception as e:
            return utils.response(utils.ERROR_TAG, utils.ERROR_MSG)
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

@login_required(login_url='/auth/login/')
def save_service(request):
    if request.method == "POST":
        try:
            with transaction.atomic():
                form_data = request.POST.copy()
                service = Service.objects.get(pk=form_data.get("ser_id"))
                ser_form = ServiceForm(data=request.POST, instance=service)
                if ser_form.is_valid():
                    service = ser_form.save()
                    service.tax = form_data.get("tax")
                    service.save()
                    utils.log_user(request.user, "Updated service {}".format(service.name))
                    return utils.response(utils.OK_TAG, utils.OK_MSG)
                else:
                    return utils.response(utils.ERROR_TAG, utils.ERROR_MSG)
        except Exception as e:
            return utils.response(utils.ERROR_TAG, utils.ERROR_MSG)
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

@login_required(login_url='/auth/login/')
def delete_service(request):
    if request.method == "POST":
        try:
            with transaction.atomic():
                form_data = request.POST.copy()
                service = Service.objects.get(pk=form_data.get("ser_id"))
                ser_name = service.name
                service.delete()
                utils.log_user(request.user, "Deleted service {}".format(ser_name))
                return utils.response(utils.OK_TAG, utils.OK_MSG)
        except Exception as e:
            return utils.response(utils.ERROR_TAG, utils.ERROR_MSG)
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)





