from django.apps import AppConfig


class SettingsappConfig(AppConfig):
    name = 'settingsapp'
