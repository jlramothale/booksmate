from django.urls import path
from . import views

app_name = "settingsapp"

urlpatterns = [
    path('', views.settings, name="settings"),
    path('companies/', views.companies, name="companies"),
    path('view-company/<str:hash>/<int:id>/', views.view_company, name="view-company"),
    path('save-company/', views.save_company, name="save-company"),
    path('add-company/', views.add_company, name="add-company"),
    path('change-company-logo/', views.change_company_logo, name="change-company-logo"),
    path('add-statutory-registration/', views.add_statutory_registration, name="add-statutory-registration"),
    path('save-statutory-registration/', views.save_statutory_registration, name="save-statutory-registration"),
    path('delete-statutory-registration/', views.delete_statutory_registration, name="delete-statutory-registration"),

    path('customers/', views.customers, name="customers"),
    path('deleted-customers/', views.deleted_customers, name="deleted-customers"),
    path('view-customer/<str:hash>/<int:id>/', views.view_customer, name="view-customer"),
    path('save-customer/', views.save_customer, name="save-customer"),
    path('delete-customer/', views.delete_customer, name="delete-customer"),
    path('activate-customer/', views.activate_customer, name="activate-customer"),
    
    path('suppliers/', views.suppliers, name="suppliers"),
    path('deleted-suppliers/', views.deleted_suppliers, name="deleted-suppliers"),
    path('view-supplier/<str:hash>/<int:id>/', views.view_supplier, name="view-supplier"),
    path('save-supplier/', views.save_supplier, name="save-supplier"),
    path('delete-supplier/', views.delete_supplier,name="delete-supplier"),
    path('activate-supplier/', views.activate_supplier,name="activate-supplier"),

    path('chart-of-accounts/', views.chart_of_accounts, name="chart-of-accounts"),

    path('products-services/', views.products_services, name="products-services"),
    path('add-product/', views.add_product, name="add-product"),
    path('save-product/', views.save_product, name="save-product"),
    path('delete-product/', views.delete_product, name="delete-product"),
    path('add-service/', views.add_service, name="add-service"),
    path('save-service/', views.save_service, name="save-service"),
    path('delete-service/', views.delete_service, name="delete-service"),
    
]
