from django.urls import path
from . import views

app_name = "authapp"

urlpatterns = [
    path('login/', views.login, name="login"),
    path('do-login/', views.do_login, name="do-login"),
    path('logout/', views.logout, name="logout"),

    path('register/', views.register, name="register"),
    path('do-register/', views.do_register, name="do-register"),

    path('complete-registration/', views.complete_registration, name="complete-registration"),
    path('do-complete-registration/', views.do_complete_registration, name="do-complete-registration"),

    path('forgot-password/', views.forgot_password, name="forgot-password"),

    path('reset-password/<str:hash>/<str:user>/<str:code>/', views.reset_password, name="reset-password"),
    path('do-reset-password/', views.do_reset_password, name="do-reset-password"),

    path('confirm-email/<str:hash>/<str:user>/<str:email>/', views.confirm_email, name="confirm-email"),
]
