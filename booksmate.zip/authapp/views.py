from django.shortcuts import render, redirect, get_object_or_404
from django.db import transaction
from django.utils import timezone
from booksmate import utils, settings
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login as user_login, logout as user_logout, authenticate
from usersapp.models import (
    Account, AccountUsers, User, Profile
)
from systemapp.models import (
    Country, Currency, Sector, Industry, BusinessType
)
from businessapp.models import (
    Business, PhysicalAddress, PostalAddress
)
from .forms import LoginForm, RegisterForm

def login(request):
    context = {}
    return render(request, "authapp/login.html", context)

def do_login(request):
    if request.method == "POST":
        form_data = request.POST.copy()
        form = LoginForm(request, request.POST)
        if form.is_valid():
            try:
                with transaction.atomic():
                    username = form.cleaned_data.get("username")
                    password = form.cleaned_data.get("password")
                    user = authenticate(username=username, password=password)
                    if user is not None:
                        user_login(request, user)
                        account_user = AccountUsers.objects.get(user=user)
                        business = Business.objects.get(account=account_user.account)
                        request.session["first_name"] = user.first_name
                        request.session["avatar"] = user.avatar.url
                        request.session["account_id"] = account_user.account.id
                        request.session["is_complete"] = account_user.account.is_complete
                        request.session["business_id"] = business.id
                        request.session["business_name"] = business.name
                        return utils.response("ok", "/dashboard/")
                    else:
                        return utils.response(utils.ERROR_TAG, "Could not login, invalid login details")
            except Exception as e:
                # transaction.rollback()
                # return utils.response(utils.ERROR_TAG, utils.ERROR_MSG)
                return utils.response("error", str(e))
        else:
            error = ""
            for msg in form.errors:
                error += "{}.<br/>".format(msg)
            return utils.response(utils.ERROR_TAG, error)

def logout(request):
    user_logout(request)
    return redirect("/auth/login/")

def register(request):
    context = {}
    return render(request, "authapp/register.html", context)

def do_register(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        form_data = request.POST.copy()
        if form.is_valid():
            try:
                with transaction.atomic():
                    user = form.save()
                    user.user_id = utils.generate_user_id()
                    user.avatar = "/static/img/default-avatar.png"
                    user.save()

                    Profile.objects.create(user=user) 

                    account = Account(date_created=timezone.now())
                    account.save()

                    AccountUsers.objects.create(user=user, account=account)

                    username = form.cleaned_data.get("username")
                    password1 = form.cleaned_data.get('password1')
                    user = authenticate(username=username, password=password1)
                    user_login(request, user)
                    request.session["first_name"] = user.first_name
                    request.session["avatar"] = user.avatar.url
                    request.session["account_id"] = account.id
                    request.session["is_complete"] = account.is_complete
                    utils.log_user(user, utils.USER_CREATES_MSG.format(user.email))

                    context = {
                        'name': user.first_name, 
                        'base_url': settings.BASE_URL,
                        "confirm_link": f"{settings.BASE_URL}/auth/confirm-email/{utils.get_hash(request)}/{user.user_id}/{user.email}/"
                    }

                    html_message = render_to_string("mails/welcome.html", context)
                    utils.email('Welcome to BooksMake', settings.EMAIL_HOST_USER, [user.email], strip_tags(html_message), html_message)
                    html_message = render_to_string("mails/confirm_email.html", context)
                    utils.email('Confirm Email Address', settings.EMAIL_HOST_USER, [user.email], strip_tags(html_message), html_message)
                    
                    return utils.response(utils.OK_TAG, "/auth/complete-registration/")
            except Exception as e:
                transaction.rollback()
                return utils.response(utils.ERROR_TAG, utils.ERROR_MSG)
        else:
            error = ""
            for msg in form.error:
                error += "{}.<br/>".format(msg)
            return utils.response(utils.ERROR_TAG, error)

def complete_registration(request):
    context = {
        "first_name": request.session["first_name"],
        "countries": Country.objects.all(),
        'currencies': Currency.objects.all(),
        "industries": Industry.objects.all(),
        "business_types": BusinessType.objects.all()
    }
    print(request.session["account_id"])
    return render(request, "authapp/complete_registration.html", context)

def do_complete_registration(request):
    if request.method == "POST":
        form_data = request.POST.copy()
        try:
            with transaction.atomic():
                account = Account.objects.get(pk=request.session["account_id"])
                currency = Currency.objects.get(pk=form_data.get("currency"))
                business = Business(
                    account=account,
                    name=form_data.get("name"),
                    reg_number=form_data.get("reg_number"),
                    reg_type=form_data.get("reg_type"),
                    year_end=form_data.get("year_end"),
                    currency=currency,
                )
                business.save()
                PhysicalAddress.objects.create(
                    business=business,
                    street_address1=form_data.get("street_address1"),
                    town_city=form_data.get("town_city"),
                    province=form_data.get("province"),
                    postal_code=form_data.get("postal_code"),
                    country=form_data.get("country"),
                )
                PostalAddress.objects.create(
                    business=business,
                )
                request.session["business_id"] = business.id
                request.session["business_name"] = business.name

                utils.log_user(request.user, "User registration complete")
                return utils.response(utils.OK_TAG, "/dashboard/")
        except Exception as e:
            transaction.rollback()
            return utils.response(utils.ERROR_TAG, utils.ERROR_MSG)
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

def forgot_password(request):
    pass

def reset_password(request):
    pass

def do_reset_password(request):
    pass

def confirm_email(request):
    pass