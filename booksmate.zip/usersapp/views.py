from django.shortcuts import render, redirect, get_object_or_404
from django.db import transaction
from django.utils import timezone
from booksmate import utils, settings
from django.contrib.auth.decorators import login_required

from .models import Profile
from .forms import UserForm

# Create your views here.
@login_required(login_url='/auth/login/')
def user_profile(request, first_name):
    context = {
        "page": "users",
        "user": request.user,
        "profile": Profile.objects.get(user=request.user)
    }
    return render(request, "usersapp/user_profile.html", context)

@login_required(login_url='/auth/login/')
def save_user(request):
    if request.method == "POST":
        form_data = request.POST.copy()
        user_form = UserForm(data=request.POST, instance=request.user)
        if user_form.is_valid():
            try:
                with transaction.atomic():
                    user = user_form.save()
                    profile = Profile.objects.get(user=user)
                    profile.position = form_data.get("position")
                    profile.contact_number = form_data.get("contact_number")
                    profile.phone_number = form_data.get("phone_number")
                    profile.save()
                    utils.log_user(request.user, f"Updated business profile")
                    return utils.response(utils.OK_TAG, utils.OK_MSG)
            except Exception as e:
                transaction.rollback()
                return utils.response(utils.ERROR_TAG, str(e))
        else:
            error = ""
            for msg in user_form.errors:
                error += "{}.<br/>".format(msg)
            return utils.response(utils.ERROR_TAG, error)
    return utils.response(utils.ERROR_TAG, utils.INVALID_REQUEST_MSG)

def change_username(request):
    pass

def change_password(request):
    pass