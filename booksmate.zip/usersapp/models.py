from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone
from systemapp.models import (
    PaymentMethod, BillingPackage
)

def user_avator_path(instance, filename):
    return 'users/{0}/{1}'.format(instance.user_id, filename)

class User(AbstractUser):
    user_id = models.CharField(max_length=256, default='', blank=True, null=True)
    user_role = models.CharField(max_length=256, default='Admin', blank=False)
    is_online = models.BooleanField(default=False, blank=True, null=True)
    is_confimed = models.BooleanField(default=False, blank=True, null=True)
    date_confirmed = models.DateTimeField(default=timezone.now, blank=True, null=True)
    avatar = models.FileField(upload_to=user_avator_path, blank=True, null=True)
    date_added = models.DateTimeField(default=timezone.now, blank=True, null=True)
    date_deleted = models.DateTimeField(default=timezone.now, blank=True, null=True)
    deleted = models.BooleanField(default=False, blank=False)

    class Meta:
        verbose_name = 'User'
        verbose_name_plural = "Users"

    def __str__(self):
        return self.email

class Profile(models.Model):
    user = models.OneToOneField(User, blank=True, null=True, on_delete=models.SET_NULL)
    position = models.CharField(max_length=128, default='', null=True, blank=True,)
    contact_number = models.CharField(max_length=16, default='', blank=True, null=True)
    phone_number = models.CharField(max_length=16, default='', blank=True, null=True)
    deleted = models.BooleanField(default=False, blank=False)

    class Meta:
        verbose_name = 'Profile'
        verbose_name_plural = "Profile"

    def __str__(self):
        return self.user.email

class Account(models.Model):
    date_created = models.DateTimeField(default=timezone.now, blank=True, null=True)
    is_complete = models.BooleanField(default=False, blank=False)
    date_completed = models.DateTimeField(default=timezone.now, blank=True, null=True)
    is_suspended = models.BooleanField(default=False, blank=False)
    date_suspended = models.DateTimeField(default=timezone.now, blank=True, null=True)
    is_removed = models.BooleanField(default=False, blank=False)
    date_removed = models.DateTimeField(default=timezone.now, blank=True, null=True)
    deleted = models.BooleanField(default=False, blank=False) 

    class Meta:
        verbose_name = 'Account'
        verbose_name_plural = "Accounts"

class AccountUsers(models.Model):
    account = models.ForeignKey(Account, blank=True, null=True, on_delete=models.SET_NULL)
    user = models.ForeignKey(User, blank=True, null=True, on_delete=models.SET_NULL)
    timestamp = models.DateTimeField(default=timezone.now, null=True)
    deleted = models.BooleanField(default=False, blank=False) 

    class Meta:
        verbose_name = 'AccountUsers'
        verbose_name_plural = "AccountUsers"

class AccountBilling(models.Model):
    account = models.ForeignKey(Account, blank=True, null=True, on_delete=models.SET_NULL)
    package = models.ForeignKey(BillingPackage, blank=True, null=True, on_delete=models.SET_NULL)
    payment_method = models.ForeignKey(PaymentMethod, blank=True, null=True, on_delete=models.SET_NULL)
    frequency = models.CharField(max_length=32, default='', blank=True, null=True)
    deleted = models.BooleanField(default=False, blank=False)

    class Meta:
        verbose_name = 'AccountBilling'
        verbose_name_plural = "AccountBilling"

class OneTimeCode(models.Model):
    user = models.ForeignKey(User, blank=True, null=True, on_delete=models.SET_NULL)
    reason = models.CharField(max_length=128, default='', null=True)
    code = models.CharField(max_length=64, default='', null=True)
    date_generated = models.DateTimeField(default=timezone.now, null=True)
    exp_length = models.CharField(max_length=4, default='60', null=True) # experation length in minutes
    is_expired = models.BooleanField(default=False, null=True)
    is_confirmed = models.BooleanField(default=False, null=True)
    date_confirmed = models.DateTimeField(default=timezone.now, null=True)
    timestamp = models.DateTimeField(default=timezone.now, null=True)
    deleted = models.BooleanField(default=False, null=True)

    class Meta:
        verbose_name = 'OneTimeCode'
        verbose_name_plural = "OneTimeCode"
    
    def __str__(self):
        return self.code

    def confirm_code(user, code):
        try:
            one_time_code = OneTimeCode.objects.filter(user=user, code=code, is_confirmed=False).order_by("-id")[0]
            if one_time_code is None:
                return False
            if one_time_code.is_expired:
                return False
            if one_time_code.code == code:
                one_time_code.is_confirmed = True
                one_time_code.date_confirmed = timezone.now()
                one_time_code.save()
                return True
            return False
        except Exception as e:
            return False

class Log(models.Model):
    user = models.ForeignKey(User, blank=True, null=True, on_delete=models.SET_NULL)
    action_time = models.DateTimeField(default=timezone.now, null=True)
    action = models.CharField(max_length=512, default='', null=True)
    ip_address = models.CharField(max_length=64, default='', null=True)
    device = models.CharField(max_length=128, default='', null=True)
    location = models.CharField(max_length=256, default='', null=True)
    timestamp = models.DateTimeField(default=timezone.now, null=True)
    deleted = models.BooleanField(default=False, null=True)

    class Meta:
        verbose_name = 'Log'
        verbose_name_plural = "Log"

    def __str__(self):
        return self.user.first_name


