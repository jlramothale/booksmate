from django import forms
from .models import User, Profile
from django.contrib.auth.forms import PasswordChangeForm

class UserForm(forms.ModelForm):
    email = forms.EmailField(max_length=256, label="Email * ", required=False, widget=forms.TextInput(attrs={'class':'form-control', 'data-rule':'required'}))
    first_name = forms.CharField(max_length=256, label = "First name * ", required=False, widget=forms.TextInput(attrs={'class':'form-control', 'data-rule':'required'}))
    last_name = forms.CharField(max_length=256, label="Last name * ", required=False, widget=forms.TextInput(attrs={'class':'form-control', 'data-rule':'required'}))
   
    class Meta:
        model = User
        fields = ["email", "first_name", "last_name"]