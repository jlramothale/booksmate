from django.urls import path
from . import views

app_name = "usersapp"

urlpatterns = [
    path('profile/<str:first_name>/', views.user_profile, name="profile"),
    path('save-user/', views.save_user, name="save-user"),
    path('change-username/', views.change_username, name='change-username'),
    path('change-password/', views.change_password, name='change-password')
]
