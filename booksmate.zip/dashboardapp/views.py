from django.shortcuts import render, redirect, get_object_or_404
from django.db import transaction
from django.utils import timezone
from booksmate import utils, settings
from django.contrib.auth.decorators import login_required

@login_required(login_url='/auth/login/')
def dashboard(request):
    context = {
        "page": "dashboard"
    }
    return render(request, "dashboardapp/dashboard.html", context)
