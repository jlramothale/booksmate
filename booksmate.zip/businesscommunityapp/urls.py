from django.urls import path
from . import views

app_name = "businesscommunityapp"

urlpatterns = [
    path('', views.business_community, name="business-community"),
    # path('save-user/', views.save_user, name="save-user"),
    # path('change-username/', views.change_username, name='change-username'),
    # path('upload-image/', UploadImageView.as_view(), name='upload-image'),
    # path('change-password/', views.change_password, name='change-password')
]
