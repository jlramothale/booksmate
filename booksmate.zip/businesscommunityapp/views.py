from django.shortcuts import render, redirect, get_object_or_404
from django.db import transaction
from django.utils import timezone
from booksmate import utils, settings
from django.contrib.auth.decorators import login_required

# Create your views here.
@login_required(login_url='/auth/login/')
def business_community(request):
    context = {
        "page": "business-community",
    }
    return render(request, "businesscommunityapp/business_community.html", context)