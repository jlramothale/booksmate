from django.apps import AppConfig


class BusinesscommunityappConfig(AppConfig):
    name = 'businesscommunityapp'
