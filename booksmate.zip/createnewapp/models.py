from django.db import models
from django.utils import timezone
from usersapp.models import Account

class Customer(models.Model):
    account = models.ForeignKey(Account, blank=True, null=True, on_delete=models.SET_NULL)
    first_name = models.CharField(max_length=256, default='', blank=True)
    last_name = models.CharField(max_length=256, default='', blank=True)
    phone_number = models.CharField(max_length=16, default='', blank=True)
    email = models.CharField(max_length=128, default='', blank=True)
    company_name = models.CharField(max_length=256, default='', blank=True)
    job_title = models.CharField(max_length=256, default='', blank=True)
    website = models.CharField(max_length=128, default='', blank=True)
    date_added = models.DateTimeField(default=timezone.now, blank=True, null=True)
    date_deleted = models.DateTimeField(default=timezone.now, blank=True, null=True)
    deleted = models.BooleanField(default=False)
    
    class Meta:
        verbose_name_plural = "Customers"
    
    def __str__(self):
        return self.first_name

class PhysicalAddress(models.Model):
    customer = models.ForeignKey(Customer, blank=True, null=True, on_delete=models.SET_NULL)
    address = models.CharField(max_length=512, default='', blank=True)
    city = models.CharField(max_length=256, default='', blank=True)
    province = models.CharField(max_length=128, default='', blank=True)
    postal_code = models.CharField(max_length=128, default='', blank=True)
    country = models.CharField(max_length=128, default='', blank=True)
    date_added = models.DateTimeField(default=timezone.now, blank=True)
    date_deleted = models.DateTimeField(default=timezone.now, null=True, blank=True)
    deleted = models.BooleanField(default=False, blank=False)

    class Meta:
        verbose_name_plural = "PhysicalAddress"

    def __str__(self):
        return self.address


