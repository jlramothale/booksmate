from django import forms
from .models import (
    Customer, PhysicalAddress
)

class CustomerForm(forms.ModelForm):
    first_name = forms.CharField(max_length=256, label="Firstname *", required=False, widget=forms.TextInput(attrs={'class':'form-control', 'data-rule':'required'}))
    last_name = forms.CharField(max_length=256, label="Lastname *", required=False, widget=forms.TextInput(attrs={'class':'form-control', 'data-rule':'required'}))
    phone_number = forms.CharField(max_length=16, label="Phone number *", required=False, widget=forms.TextInput(attrs={'class':'form-control', 'data-rule':'required'}))
    email = forms.EmailField(max_length=256, label="Email address *", required=False, widget=forms.TextInput(attrs={'class':'form-control', 'data-rule':'required'}))
    company_name = forms.CharField(max_length=256, label="Company name", required=False, widget=forms.TextInput(attrs={'class':'form-control',}))
    job_title = forms.CharField(max_length=256, label="Job title", required=False, widget=forms.TextInput(attrs={'class':'form-control',}))
    website = forms.CharField(max_length=256, label="Website", required=False, widget=forms.TextInput(attrs={'class':'form-control',}))

    class Meta:
        model = Customer
        fields = [
            "first_name", "last_name", "phone_number", "email", "job_title", 
            "company_name", "website"
        ]

class PhysicalAddressForm(forms.ModelForm):
    address = forms.CharField(max_length=256, label="Address", required=False, widget=forms.TextInput(attrs={'class':'form-control',}))
    city = forms.CharField(max_length=256, label="City", required=False, widget=forms.TextInput(attrs={'class':'form-control',}))
    province = forms.CharField(max_length=256, label="Province", required=False, widget=forms.TextInput(attrs={'class':'form-control col-6',}))
    postal_code = forms.CharField(max_length=256, label="Postal code", required=False, widget=forms.TextInput(attrs={'class':'form-control col-6',}))

    class Meta:
        model = PhysicalAddress
        fields = [
            "address", "city", "postal_code", "province", 
        ]