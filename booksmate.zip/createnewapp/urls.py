from django.urls import path
from . import views

app_name = "createnewapp"

urlpatterns = [
    path('', views.createnew, name="createnew"),
    path('new-customer/', views.new_customer, name="new-customer"),
    path('new-supplier/', views.new_supplier, name='new-supplier'),
    path('new-order/', views.new_order, name='new-order'),
    path('new-quote/', views.new_quote, name='new-ordquoteer'),
    path('new-invoice/', views.new_invoice, name='new-invoice'),
    path('new-receipt/', views.new_receipt, name='new-receipt'),
    path('allocate-payments/', views.allocate_payments, name='allocate-payments'),
]
