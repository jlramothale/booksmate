from django.apps import AppConfig


class CreatenewappConfig(AppConfig):
    name = 'createnewapp'
