from django.shortcuts import render, redirect, get_object_or_404
from django.db import transaction
from django.utils import timezone
from booksmate import utils, settings
from django.contrib.auth.decorators import login_required
from systemapp.models import (
    Country
)
from .models import (
    Customer, PhysicalAddress
)
from .forms import (
    CustomerForm, PhysicalAddressForm
)
from usersapp.models import (
    Account
)
from businessapp.forms import (
    SupplierForm
)

# Create your views here.
@login_required(login_url='/auth/login/')
def createnew(request):
    context = {
        "page": "createnew",
    }
    return render(request, "createnewapp/createnew.html", context)

@login_required(login_url='/auth/login/')
def new_customer(request):
    if request.method == "POST":
        form_data = request.POST.copy()
        customer_form = CustomerForm(data=request.POST)
        if customer_form.is_valid():
            try:
                with transaction.atomic():
                    account = Account.objects.get(pk=request.session["account_id"])
                    customer = customer_form.save()
                    customer.account = account
                    customer.save()
                    PhysicalAddress.objects.create(
                        customer=customer,
                        address=form_data.get("address"),
                        city=form_data.get("city"),
                        province=form_data.get("province"),
                        postal_code=form_data.get("postal_code"),
                        country=form_data.get("country")
                    )
                    utils.log_user(request.user, f"New customer added")
                    return utils.response(utils.OK_TAG, utils.OK_MSG)
            except Exception as e:
                transaction.rollback()
                return utils.response(utils.ERROR_TAG, str(e))
        else:
            error = ""
            for msg in customer_form.errors:
                error += "SSSSS{}.<br/>".format(msg)
            return utils.response(utils.ERROR_TAG, error)
    else:
        context = {
            "page": "createnew",
            "customer_form": CustomerForm(),
            "physical_address_form": PhysicalAddressForm(),
            "countries": Country.objects.all()
        }
        return render(request, "createnewapp/new_customer.html", context)

@login_required(login_url='/auth/login/')
def new_supplier(request):
    if request.method == "POST":
        form_data = request.POST.copy()
        try:
            with transaction.atomic():
                supplier_form = SupplierForm(data=request.POST)
                if supplier_form.is_valid():
                    account = Account.objects.get(pk=request.session["account_id"])
                    supplier = supplier_form.save()
                    supplier.account = account
                    supplier.save()
                    utils.log_user(request.user, f"New supplier added")
                    return utils.response(utils.OK_TAG, utils.OK_MSG)
                else:
                    error = ""
                    for msg in supplier_form.errors:
                        error += "{}.<br/>".format(msg)
                    return utils.response(utils.ERROR_TAG, error)
        except Exception as e:
            transaction.rollback()
            return utils.response(utils.ERROR_TAG, str(e))
    else:
        context = {
            "page": "createnew",
            "supplier_form": SupplierForm(),
            "countries": Country.objects.all()
        }
        return render(request, "createnewapp/new_supplier.html", context)

@login_required(login_url='/auth/login/')
def new_order(request):
    context = {
        "page": "createnew",
    }
    return render(request, "createnewapp/new_order.html", context)

@login_required(login_url='/auth/login/')
def new_quote(request):
    context = {
        "page": "createnew",
    }
    return render(request, "createnewapp/new_quote.html", context)

@login_required(login_url='/auth/login/')
def new_invoice(request):
    context = {
        "page": "createnew",
    }
    return render(request, "createnewapp/new_invoice.html", context)

@login_required(login_url='/auth/login/')
def new_receipt(request):
    context = {
        "page": "createnew",
    }
    return render(request, "createnewapp/new_receipt.html", context)

@login_required(login_url='/auth/login/')
def allocate_payments(request):
    context = {
        "page": "createnew",
    }
    return render(request, "createnewapp/allocate_payments.html", context)